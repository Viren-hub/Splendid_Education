// Production environment
// API_URL is set as an environment variable in Netlify dashboard:
//   Site configuration → Environment variables → API_URL
export const environment = {
  production: true,
  apiUrl: 'API_URL_PLACEHOLDER',
};
