import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminShellComponent } from './admin-shell/admin-shell.component';

@NgModule({
  declarations: [AdminShellComponent],
  imports: [AdminRoutingModule, SharedModule],
})
export class AdminModule {}
