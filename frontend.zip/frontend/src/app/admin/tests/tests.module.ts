import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AdminTestsComponent } from './tests.component';

@NgModule({
  declarations: [AdminTestsComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: AdminTestsComponent }]),
  ],
})
export class TestsModule {}
