import { Component, OnInit } from '@angular/core';
import { AdminDataService } from '../../core/services/admin-data.service';
import { AlertService } from '../../core/services/alert.service';

interface Question {
  _id?: string;
  text: string;
  marks: number;
  explanation: string;
  options: { _id?: string; text: string; isCorrect: boolean }[];
}

@Component({
  selector: 'app-admin-tests',
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.css'],
})
export class AdminTestsComponent implements OnInit {
  // ── View state ─────────────────────────────────────────
  view: 'list' | 'form' | 'results' = 'list';

  // ── List ───────────────────────────────────────────────
  quizzes:  any[] = [];
  loading   = false;
  listError = '';

  // ── Form (create / edit) ───────────────────────────────
  editId       = '';
  saving       = false;
  formError    = '';
  formSuccess  = '';

  title        = '';
  description  = '';
  assignType: 'all' | 'batch' = 'all';
  assignBatch  = '';
  duration     = 30;
  passingMarks = 40;
  isActive     = true;
  questions: Question[] = [];

  batches:  any[] = [];

  // ── Import ────────────────────────────────────────────────
  importError   = '';
  importSuccess = false;
  importCount   = 0;

  // ── Results ────────────────────────────────────────────
  resultsQuiz:    any    = null;
  attempts:       any[]  = [];
  resultStats:    any    = null;
  loadingResults  = false;
  deletingId      = '';

  // ── Delete confirm modal ───────────────────────────────
  showDeleteModal  = false;
  deleteTargetId   = '';
  deleteTargetName = '';

  constructor(private svc: AdminDataService, private alert: AlertService) {}

  ngOnInit(): void {
    this.loadList();
    this.svc.getBatches().subscribe({ next: (r: any) => this.batches  = r.data || [] });
  }

  // ── LIST ───────────────────────────────────────────────
  loadList(): void {
    this.loading = true; this.listError = '';
    this.svc.getAllQuizzes().subscribe({
      next:  (r: any) => { this.quizzes = r.data || []; this.loading = false; },
      error: (e: any) => { this.listError = e?.error?.message || 'Failed to load quizzes'; this.loading = false; },
    });
  }

  // ── FORM (CREATE) ──────────────────────────────────────
  openCreateForm(): void {
    this.editId = ''; this.formError = ''; this.formSuccess = '';
    this.title = ''; this.description = ''; this.assignType = 'all';
    this.assignBatch = '';
    this.duration = 30; this.passingMarks = 40; this.isActive = true;
    this.questions = [];
    this.addQuestion();
    this.view = 'form';
  }

  // ── FORM (EDIT) ────────────────────────────────────────
  openEditForm(quiz: any): void {
    this.svc.getQuizAdmin(quiz.id).subscribe({
      next: (r: any) => {
        const q = r.data;
        this.editId = q.id; this.formError = ''; this.formSuccess = '';
        this.title = q.title; this.description = q.description || '';
        this.assignType   = q.assignedTo?.type   || 'all';
        this.assignBatch  = q.assignedTo?.batch?.id  || q.assignedTo?.batch  || '';
        this.duration     = q.duration || 30;
        this.passingMarks = q.passingMarks || 40;
        this.isActive     = q.isActive ?? true;
        this.questions    = (q.questions || []).map((qn: any) => ({
          _id: qn.id || qn._id, text: qn.text, marks: qn.marks || 1, explanation: qn.explanation || '',
          options: (qn.options || []).map((o: any) => ({ _id: o.id || o._id, text: o.text, isCorrect: o.isCorrect })),
        }));
        if (!this.questions.length) this.addQuestion();
        this.view = 'form';
      },
      error: (e: any) => this.alert.show(e?.error?.message || 'Failed to load quiz'),
    });
  }

  // ── QUESTION MANAGEMENT ────────────────────────────────
  addQuestion(): void {
    this.questions.push({
      text: '', marks: 1, explanation: '',
      options: [
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
        { text: '', isCorrect: false },
      ],
    });
  }

  removeQuestion(i: number): void { this.questions.splice(i, 1); }

  addOption(qi: number): void { this.questions[qi].options.push({ text: '', isCorrect: false }); }

  removeOption(qi: number, oi: number): void {
    if (this.questions[qi].options.length > 2) this.questions[qi].options.splice(oi, 1);
  }

  setCorrect(qi: number, oi: number): void {
    this.questions[qi].options.forEach((o, i) => o.isCorrect = i === oi);
  }

  // ── SAVE ───────────────────────────────────────────────
  saveQuiz(): void {
    this.formError = ''; this.formSuccess = '';
    if (!this.title.trim()) { this.formError = 'Quiz title is required.'; return; }
    if (!this.questions.length) { this.formError = 'Add at least one question.'; return; }

    for (let i = 0; i < this.questions.length; i++) {
      const q = this.questions[i];
      if (!q.text.trim()) { this.formError = `Question ${i + 1} text is empty.`; return; }
      if (!q.options.some(o => o.text.trim())) { this.formError = `Question ${i + 1} has empty options.`; return; }
      if (!q.options.some(o => o.isCorrect))   { this.formError = `Question ${i + 1} has no correct answer selected.`; return; }
    }

    const payload = {
      title: this.title.trim(), description: this.description.trim(),
      assignedTo: {
        type:   this.assignType,
        batch:  this.assignType === 'batch'  ? this.assignBatch  : null,
      },
      questions: this.questions.map(q => ({
        text: q.text.trim(), marks: q.marks, explanation: q.explanation.trim(),
        options: q.options.filter(o => o.text.trim()).map(o => ({ text: o.text.trim(), isCorrect: o.isCorrect })),
      })),
      duration: this.duration, passingMarks: this.passingMarks, isActive: this.isActive,
    };

    this.saving = true;
    const call = this.editId
      ? this.svc.updateQuiz(this.editId, payload)
      : this.svc.createQuiz(payload);

    call.subscribe({
      next: () => {
        this.saving = false;
        this.formSuccess = this.editId ? 'Quiz updated!' : 'Quiz created!';
        setTimeout(() => { this.loadList(); this.view = 'list'; }, 1200);
      },
      error: (e: any) => { this.formError = e?.error?.message || 'Save failed'; this.saving = false; },
    });
  }

  cancelForm(): void { this.view = 'list'; }

  // ── DELETE ────────────────────────────────────────────
  deleteQuiz(id: string): void {
    const quiz = this.quizzes.find((q: any) => q.id === id);
    this.deleteTargetId   = id;
    this.deleteTargetName = quiz?.title || 'this quiz';
    this.showDeleteModal  = true;
  }

  confirmDelete(): void {
    this.showDeleteModal = false;
    this.deletingId = this.deleteTargetId;
    this.svc.deleteQuiz(this.deleteTargetId).subscribe({
      next: () => { this.deletingId = ''; this.loadList(); },
      error: (e: any) => { this.alert.show(e?.error?.message || 'Delete failed'); this.deletingId = ''; },
    });
  }

  cancelDelete(): void {
    this.showDeleteModal  = false;
    this.deleteTargetId   = '';
    this.deleteTargetName = '';
  }

  // ── RESULTS ───────────────────────────────────────────
  openResults(quiz: any): void {
    this.resultsQuiz = null; this.attempts = []; this.resultStats = null;
    this.loadingResults = true;
    this.svc.getQuizResults(quiz.id).subscribe({
      next: (r: any) => {
        this.resultsQuiz  = r.data.quiz;
        this.attempts     = r.data.attempts || [];
        this.resultStats  = r.data.stats;
        this.loadingResults = false;
        this.view = 'results';
      },
      error: (e: any) => { this.alert.show(e?.error?.message || 'Failed to load results'); this.loadingResults = false; },
    });
  }

  // ── IMPORT ───────────────────────────────────────────────
  triggerImport(): void {
    this.importError = ''; this.importSuccess = false;
    (document.getElementById('quizImportInput') as HTMLInputElement)?.click();
  }

  onImportFile(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    this.importError = ''; this.importSuccess = false;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const ext = file.name.split('.').pop()?.toLowerCase();
        let parsed: Question[] = [];
        if (ext === 'json') {
          parsed = this.parseJsonQuestions(content);
        } else if (ext === 'csv') {
          parsed = this.parseCsvQuestions(content);
        } else {
          this.importError = 'Unsupported format. Upload a .json or .csv file.';
          return;
        }
        if (!parsed.length) { this.importError = 'No valid questions found in file.'; return; }
        // If the only existing question is the blank auto-added placeholder, replace it
        const hasOnlyBlankPlaceholder = this.questions.length === 1 && !this.questions[0].text.trim();
        if (hasOnlyBlankPlaceholder) {
          this.questions = parsed;
        } else {
          this.questions.push(...parsed);
        }
        this.importCount = parsed.length;
        this.importSuccess = true;
        setTimeout(() => this.importSuccess = false, 5000);
      } catch (err: any) {
        this.importError = err.message || 'Failed to parse file.';
      }
      (event.target as HTMLInputElement).value = '';
    };
    reader.readAsText(file);
  }

  private parseJsonQuestions(content: string): Question[] {
    const arr = JSON.parse(content);
    if (!Array.isArray(arr)) throw new Error('JSON must be an array of question objects.');
    return arr.map((q: any, i: number) => {
      if (!q.text || typeof q.text !== 'string')
        throw new Error(`Question ${i + 1}: "text" field is required.`);
      if (!Array.isArray(q.options) || q.options.length < 2)
        throw new Error(`Question ${i + 1}: at least 2 options are required.`);
      if (!q.options.some((o: any) => o.isCorrect))
        throw new Error(`Question ${i + 1}: no correct answer marked (set isCorrect: true on one option).`);
      return {
        text: q.text.trim(),
        marks: Math.max(1, Number(q.marks) || 1),
        explanation: q.explanation?.trim() || '',
        options: q.options.map((o: any) => ({ text: String(o.text).trim(), isCorrect: !!o.isCorrect })),
      };
    });
  }

  private parseCsvQuestions(content: string): Question[] {
    const lines = content.split(/\r?\n/).filter(l => l.trim());
    if (lines.length < 2) throw new Error('CSV must have a header row and at least one data row.');
    return lines.slice(1).map((line, i) => {
      const cols = this.parseCsvLine(line);
      if (cols.length < 6)
        throw new Error(`Row ${i + 2}: need at least 6 columns — question, option1, option2, option3, option4, correct.`);
      const [qText, opt1, opt2, opt3, opt4, correctStr, marksStr, explanation] = cols;
      const correct = parseInt(correctStr, 10);
      if (!qText.trim()) throw new Error(`Row ${i + 2}: question text is empty.`);
      if (isNaN(correct) || correct < 1 || correct > 4)
        throw new Error(`Row ${i + 2}: "correct" must be 1–4 (the index of the correct option).`);
      const options = [opt1, opt2, opt3, opt4]
        .filter(o => o?.trim())
        .map((text, idx) => ({ text: text.trim(), isCorrect: idx + 1 === correct }));
      if (options.length < 2) throw new Error(`Row ${i + 2}: at least 2 non-empty options required.`);
      if (!options.some(o => o.isCorrect))
        throw new Error(`Row ${i + 2}: correct index (${correct}) points to an empty/missing option.`);
      return {
        text: qText.trim(),
        marks: Math.max(1, Number(marksStr) || 1),
        explanation: explanation?.trim() || '',
        options,
      };
    });
  }

  private parseCsvLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
        else inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        result.push(current); current = '';
      } else {
        current += ch;
      }
    }
    result.push(current);
    return result;
  }

  downloadSample(format: 'json' | 'csv'): void {
    let content: string, mime: string, filename: string;
    if (format === 'json') {
      content = JSON.stringify([
        {
          text: 'What does HTML stand for?',
          marks: 1,
          explanation: 'HTML is the standard markup language for creating web pages.',
          options: [
            { text: 'Hyper Text Markup Language', isCorrect: true },
            { text: 'High Tech Modern Language', isCorrect: false },
            { text: 'Hyper Transfer Markup Language', isCorrect: false },
            { text: 'Home Tool Markup Language', isCorrect: false },
          ],
        },
        {
          text: 'Which symbol is used for comments in Python?',
          marks: 2,
          explanation: 'The # symbol starts a single-line comment in Python.',
          options: [
            { text: '//', isCorrect: false },
            { text: '#', isCorrect: true },
            { text: '/* */', isCorrect: false },
            { text: '--', isCorrect: false },
          ],
        },
      ], null, 2);
      mime = 'application/json'; filename = 'sample_questions.json';
    } else {
      content = [
        'question,option1,option2,option3,option4,correct,marks,explanation',
        '"What does HTML stand for?","Hyper Text Markup Language","High Tech Modern Language","Hyper Transfer Markup Language","Home Tool Markup Language",1,1,"HTML is the standard markup language."',
        '"Which symbol is used for comments in Python?","//","#","/* */","--",2,2,"The # symbol starts a single-line comment in Python."',
      ].join('\n');
      mime = 'text/csv'; filename = 'sample_questions.csv';
    }
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  // ── HELPERS ───────────────────────────────────────────
  assignLabel(quiz: any): string {
    if (!quiz) return '—';
    const t = quiz.assignedTo?.type;
    if (!t || t === 'all')    return 'All Students';
    if (t === 'batch')  return `Batch: ${quiz.assignedTo?.batch?.batchName || '—'}`;
    return '—';
  }

  formatTime(secs: number): string {
    if (!secs) return '—';
    const m = Math.floor(secs / 60), s = secs % 60;
    return `${m}m ${s}s`;
  }

  trackByIndex(i: number): number { return i; }
}
