import { Component, OnInit } from '@angular/core';
import { AdminDataService } from '../../core/services/admin-data.service';

type FilterStatus = '' | 'pending_payment' | 'utr_submitted' | 'payment_confirmed' | 'rejected';

@Component({
  selector: 'app-admin-enrollments',
  templateUrl: './enrollments.component.html',
  styleUrls: ['./enrollments.component.css'],
})
export class AdminEnrollmentsComponent implements OnInit {
  enrollments: any[] = [];
  loading = false;
  filterStatus: FilterStatus = 'utr_submitted';

  // Modal state
  activeModal: 'utr' | 'reject' | 'confirm' | 'reopen' | 'delete' | null = null;
  selectedEnrollment: any = null;
  modalUtrValue = '';
  modalAdminNote = '';
  modalRejectReason = '';
  actionLoading = false;
  actionError = '';
  actionSuccess = '';

  // Confirm success details (to show temp password)
  confirmedData: any = null;

  // Confirm form fields
  confirmCourseFee = 0;
  confirmAmountPaid = 0;
  confirmCourseId = '';
  confirmBatchId = '';
  confirmDueDate = '';

  batches: any[] = [];

  constructor(private adminData: AdminDataService) {}

  ngOnInit(): void {
    this.loadEnrollments();
    this.adminData.getBatches().subscribe({ next: (r: any) => this.batches = r.data || [] });
  }

  loadEnrollments(): void {
    this.loading = true;
    this.adminData.getAllEnrollments(this.filterStatus || undefined).subscribe({
      next: (res: any) => {
        this.enrollments = res.data || [];
        this.loading = false;
      },
      error: () => { this.loading = false; },
    });
  }

  setFilter(s: FilterStatus): void {
    this.filterStatus = s;
    this.loadEnrollments();
  }

  statusLabel(s: string): string {
    const map: Record<string, string> = {
      pending_payment: 'Pending Payment',
      utr_submitted: 'UTR Submitted',
      payment_confirmed: 'Confirmed',
      rejected: 'Rejected',
    };
    return map[s] || s;
  }

  statusClass(s: string): string {
    const map: Record<string, string> = {
      pending_payment: 'status-pending',
      utr_submitted: 'status-utr',
      payment_confirmed: 'status-confirmed',
      rejected: 'status-rejected',
    };
    return map[s] || '';
  }

  // ── Open modals ────────────────────────────────────────
  openUtrModal(e: any): void {
    this.selectedEnrollment = e;
    this.modalUtrValue = e.utrNumber || '';
    this.modalAdminNote = '';
    this.actionError = '';
    this.actionSuccess = '';
    this.activeModal = 'utr';
  }

  openRejectModal(e: any): void {
    this.selectedEnrollment = e;
    this.modalRejectReason = '';
    this.actionError = '';
    this.actionSuccess = '';
    this.activeModal = 'reject';
  }

  openReopenModal(e: any): void {
    this.selectedEnrollment = e;
    this.actionError = '';
    this.activeModal = 'reopen';
  }

  openDeleteModal(e: any): void {
    this.selectedEnrollment = e;
    this.actionError = '';
    this.activeModal = 'delete';
  }

  openConfirmModal(e: any): void {
    this.selectedEnrollment = e;
    this.confirmedData = null;
    this.actionError = '';
    this.actionSuccess = '';
    // Pre-fill with enrollment's existing courseFee if any
    this.confirmCourseFee  = e.courseFee || 0;
    this.confirmAmountPaid = e.courseFee || 0;
    this.confirmBatchId    = '';
    this.confirmDueDate    = '';
    this.activeModal = 'confirm';
  }

  closeModal(): void {
    this.activeModal = null;
    this.selectedEnrollment = null;
    this.actionError = '';
    this.actionSuccess = '';
  }

  // ── Actions ────────────────────────────────────────────
  submitAdminUTR(): void {
    if (!this.modalUtrValue.trim()) { this.actionError = 'Please enter the UTR number.'; return; }
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.adminEnterUTR(this.selectedEnrollment.id, {
      utrNumber: this.modalUtrValue.trim(),
      adminNote: this.modalAdminNote.trim() || undefined,
    }).subscribe({
      next: () => {
        this.actionLoading = false;
        this.closeModal();
        this.loadEnrollments();
      },
      error: (err: any) => {
        this.actionLoading = false;
        this.actionError = err?.error?.message || 'Failed to save UTR.';
      },
    });
  }

  submitConfirm(): void {
    this.actionLoading = true;
    this.actionError = '';
    const payload: any = {
      courseFee:   this.confirmCourseFee,
      amountPaid:  this.confirmAmountPaid,
    };
    if (this.confirmBatchId)  payload.batchId  = this.confirmBatchId;
    if (this.confirmDueDate)  payload.dueDate  = this.confirmDueDate;

    this.adminData.confirmEnrollment(this.selectedEnrollment.id, payload).subscribe({
      next: (res: any) => {
        this.actionLoading = false;
        this.confirmedData = res.data;
        this.loadEnrollments();
      },
      error: (err: any) => {
        this.actionLoading = false;
        this.actionError = err?.error?.message || 'Confirmation failed.';
      },
    });
  }

  submitReject(): void {
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.rejectEnrollment(this.selectedEnrollment.id, this.modalRejectReason || 'Payment not verified.').subscribe({
      next: () => {
        this.actionLoading = false;
        this.closeModal();
        this.loadEnrollments();
      },
      error: (err: any) => {
        this.actionLoading = false;
        this.actionError = err?.error?.message || 'Rejection failed.';
      },
    });
  }

  submitReopen(): void {
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.reopenEnrollment(this.selectedEnrollment.id).subscribe({
      next: () => {
        this.actionLoading = false;
        this.closeModal();
        this.loadEnrollments();
      },
      error: (err: any) => {
        this.actionLoading = false;
        this.actionError = err?.error?.message || 'Failed to re-open.';
      },
    });
  }

  submitDelete(): void {
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.deleteEnrollment(this.selectedEnrollment.id).subscribe({
      next: () => {
        this.actionLoading = false;
        this.closeModal();
        this.loadEnrollments();
      },
      error: (err: any) => {
        this.actionLoading = false;
        this.actionError = err?.error?.message || 'Delete failed.';
      },
    });
  }}