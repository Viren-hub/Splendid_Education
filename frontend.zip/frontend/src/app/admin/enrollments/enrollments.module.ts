import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AdminEnrollmentsComponent } from './enrollments.component';

@NgModule({
  declarations: [AdminEnrollmentsComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: AdminEnrollmentsComponent }]),
  ],
})
export class EnrollmentsModule {}
