import { Component, OnInit } from '@angular/core';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-student-directory',
  templateUrl: './student-directory.component.html',
  styleUrls: ['./student-directory.component.css']
})
export class StudentDirectoryComponent implements OnInit {
  students: any[] = [];
  loading = true;
  searchTerm = '';
  total = 0;

  filterYear  = '';
  filterMonth = '';
  filterGrade = '';

  unarchivingId: string | null = null;
  toast: string | null = null;

  // Unarchive confirmation modal
  showUnarchiveModal = false;
  pendingUnarchiveStudent: any = null;

  years: string[] = this.buildYears();

  months = [
    { val: '1',  label: 'January'   }, { val: '2',  label: 'February'  },
    { val: '3',  label: 'March'     }, { val: '4',  label: 'April'     },
    { val: '5',  label: 'May'       }, { val: '6',  label: 'June'      },
    { val: '7',  label: 'July'      }, { val: '8',  label: 'August'    },
    { val: '9',  label: 'September' }, { val: '10', label: 'October'   },
    { val: '11', label: 'November'  }, { val: '12', label: 'December'  },
  ];

  grades = ['3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th'];

  constructor(private adminData: AdminDataService) {}

  ngOnInit() {
    this.load();
  }

  buildYears(): string[] {
    const now = new Date();
    const cal = now.getFullYear();
    const currentStart = now.getMonth() < 5 ? cal - 1 : cal;
    const arr: string[] = [];
    for (let y = currentStart; y >= 2019; y--) {
      arr.push(`${y}-${String(y + 1).slice(-2)}`);
    }
    return arr;
  }

  load() {
    this.loading = true;
    const params: any = {};
    if (this.searchTerm)  params['search'] = this.searchTerm;
    if (this.filterYear)  params['year']   = this.filterYear;
    if (this.filterMonth) params['month']  = this.filterMonth;
    if (this.filterGrade) params['grade']  = this.filterGrade;
    this.adminData.getStudentHistory(params).subscribe({
      next: (r: any) => {
        this.students = r.data || [];
        this.total = r.total || this.students.length;
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  hasFilters(): boolean {
    return !!(this.searchTerm || this.filterYear || this.filterMonth || this.filterGrade);
  }

  clearFilters() {
    this.searchTerm  = '';
    this.filterYear  = '';
    this.filterMonth = '';
    this.filterGrade = '';
    this.load();
  }

  confirmUnarchive(s: any) {
    this.pendingUnarchiveStudent = s;
    this.showUnarchiveModal = true;
  }

  closeUnarchiveModal() {
    this.showUnarchiveModal = false;
    this.pendingUnarchiveStudent = null;
  }

  unarchive(s: any) {
    if (!s) return;
    this.unarchivingId = s.id;
    this.showUnarchiveModal = false;
    this.adminData.updateStudent(s.id, { isActive: true }).subscribe({
      next: () => {
        this.unarchivingId = null;
        this.pendingUnarchiveStudent = null;
        this.showToast(`${s.user?.name} restored as a fresh active student.`);
        this.load();
      },
      error: () => { this.unarchivingId = null; }
    });
  }

  showToast(msg: string) {
    this.toast = msg;
    setTimeout(() => { this.toast = null; }, 3500);
  }

  copyText(val: string) {
    navigator.clipboard?.writeText(val);
  }
}
