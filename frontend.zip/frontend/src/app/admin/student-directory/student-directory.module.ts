import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { StudentDirectoryComponent } from './student-directory.component';

@NgModule({
  declarations: [StudentDirectoryComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: StudentDirectoryComponent }]),
  ],
})
export class StudentDirectoryModule {}
