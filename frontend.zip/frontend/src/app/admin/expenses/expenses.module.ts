import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { ExpensesComponent } from './expenses.component';

@NgModule({
  declarations: [ExpensesComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: ExpensesComponent }]),
  ],
})
export class ExpensesModule {}
