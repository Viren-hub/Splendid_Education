import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.component.html',
  styleUrls: ['./expenses.component.css']
})
export class ExpensesComponent implements OnInit {
  expenses: any[] = [];
  summary: { total: number; byCategory: { category: string; amount: number }[] } | null = null;
  loading = true;
  showForm = false;
  editMode = false;
  editId = '';
  form!: FormGroup;
  saving = false;
  error = '';
  monthFilter = '';
  categoryFilter = '';
  showDeleteModal = false;
  deleteTargetId = '';
  deleteTargetDesc = '';
  months = [
    { value: '1', label: 'January' }, { value: '2', label: 'February' },
    { value: '3', label: 'March' },   { value: '4', label: 'April' },
    { value: '5', label: 'May' },     { value: '6', label: 'June' },
    { value: '7', label: 'July' },    { value: '8', label: 'August' },
    { value: '9', label: 'September' },{ value: '10', label: 'October' },
    { value: '11', label: 'November' },{ value: '12', label: 'December' },
  ];

  constructor(private adminData: AdminDataService, private fb: FormBuilder) {}

  ngOnInit() { this.initForm(); this.loadExpenses(); }

  initForm(e?: any) {
    this.form = this.fb.group({
      description: [e?.description || e?.title || '', Validators.required],
      amount: [e?.amount || 0, [Validators.required, Validators.min(1)]],
      category: [e?.category || '', Validators.required],
      date: [e?.date ? e.date.substring(0, 10) : new Date().toISOString().substring(0, 10)],
      notes: [e?.notes || e?.description || '']
    });
  }

  loadExpenses() {
    this.loading = true;
    this.error = '';
    this.adminData.getAllExpenses({ category: this.categoryFilter }).subscribe({
      next: (r: any) => {
        this.expenses = r.data || [];
        const total = r.totalAmount || this.expenses.reduce((s: number, e: any) => s + e.amount, 0);
        this.summary = { total, byCategory: [] };
        this.loading = false;
      },
      error: () => { this.error = 'Failed to load expenses.'; this.loading = false; }
    });
  }

  openCreate() { this.editId = ''; this.editMode = false; this.initForm(); this.showForm = true; }
  edit(e: any) { this.editId = e.id; this.editMode = true; this.initForm(e); this.showForm = true; }
  closeForm() { this.showForm = false; }

  save() {
    if (this.form.invalid) return;
    this.saving = true;
    const payload = { ...this.form.value, title: this.form.value.description };
    const obs = this.editMode
      ? this.adminData.updateExpense(this.editId, payload)
      : this.adminData.createExpense(payload);
    obs.subscribe({
      next: () => { this.saving = false; this.showForm = false; this.loadExpenses(); },
      error: () => { this.saving = false; }
    });
  }

  openDeleteModal(id: string, desc: string) {
    this.deleteTargetId = id;
    this.deleteTargetDesc = desc;
    this.showDeleteModal = true;
  }
  confirmDelete() {
    this.showDeleteModal = false;
    this.adminData.deleteExpense(this.deleteTargetId).subscribe({ next: () => this.loadExpenses() });
  }
  cancelDelete() { this.showDeleteModal = false; }
}
