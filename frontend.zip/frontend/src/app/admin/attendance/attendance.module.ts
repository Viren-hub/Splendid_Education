import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AttendanceComponent } from './attendance.component';

@NgModule({
  declarations: [AttendanceComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: AttendanceComponent }]),
  ],
})
export class AttendanceModule {}
