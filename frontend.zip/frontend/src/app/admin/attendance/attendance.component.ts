import { Component, OnInit } from '@angular/core';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  // ── Data ──────────────────────────────────────────────────
  batches: any[]  = [];
  records: any[]  = [];
  students: any[] = [];   // students of the selected batch

  // ── Selection state ───────────────────────────────────────
  selectedBatch      = '';
  selectedBatchObj: any = null;
  activeTab: 'view' | 'mark' = 'view';

  // ── Mark-attendance form ──────────────────────────────────
  markDate    = new Date().toISOString().split('T')[0];  // today YYYY-MM-DD
  markSubject = '';
  /** map studentId → status */
  markStatus: { [studentId: string]: 'present' | 'absent' | 'late' } = {};

  // ── UI state ──────────────────────────────────────────────
  loadingBatches = true;
  loadingRecords = false;
  loadingStudents = false;
  saving          = false;
  saveError       = '';
  saveSuccess     = false;

  // ── Date filter for view ──────────────────────────────────
  filterFrom = '';
  filterTo   = '';

  constructor(private adminData: AdminDataService) {}

  trackRecord(_: number, r: any) { return r.id ?? _; }
  trackStudent(_: number, s: any) { return s.id; }

  ngOnInit() {
    this.adminData.getBatches().subscribe({
      next: (r: any) => { this.batches = r.data || []; this.loadingBatches = false; },
      error: () => this.loadingBatches = false
    });
  }

  // ── Batch date helpers ───────────────────────────────────
  get batchMinDate(): string {
    if (!this.selectedBatchObj?.startDate) return '';
    return new Date(this.selectedBatchObj.startDate).toISOString().split('T')[0];
  }

  get batchMaxDate(): string {
    const today = new Date().toISOString().split('T')[0];
    if (!this.selectedBatchObj?.endDate) return today;
    const end = new Date(this.selectedBatchObj.endDate).toISOString().split('T')[0];
    return end < today ? end : today;
  }

  get markDateOutOfRange(): boolean {
    if (!this.markDate || !this.selectedBatchObj) return false;
    if (this.batchMinDate && this.markDate < this.batchMinDate) return true;
    if (this.batchMaxDate && this.markDate > this.batchMaxDate) return true;
    return false;
  }

  onBatchChange() {
    if (!this.selectedBatch) {
      this.selectedBatchObj = null; this.records = []; this.students = []; return;
    }
    this.selectedBatchObj = this.batches.find(b => b.id === this.selectedBatch) || null;
    this.records = []; this.students = []; this.saveSuccess = false; this.saveError = '';

    // Clamp markDate to batch date range
    if (this.batchMinDate && this.markDate < this.batchMinDate) this.markDate = this.batchMinDate;
    if (this.batchMaxDate && this.markDate > this.batchMaxDate) this.markDate = this.batchMaxDate;

    if (this.activeTab === 'view') this.loadRecords();
    else this.loadStudents();
  }

  switchTab(tab: 'view' | 'mark') {
    this.activeTab = tab;
    this.saveSuccess = false; this.saveError = '';
    if (!this.selectedBatch) return;
    if (tab === 'view')  this.loadRecords();
    if (tab === 'mark')  this.loadStudents();
  }

  loadRecords() {
    this.loadingRecords = true;
    const params: any = {};
    if (this.filterFrom) params.from = this.filterFrom;
    if (this.filterTo)   params.to   = this.filterTo;
    this.adminData.getBatchAttendance(this.selectedBatch, params).subscribe({
      next: (r: any) => { this.records = r.data || []; this.loadingRecords = false; },
      error: () => this.loadingRecords = false
    });
  }

  loadStudents() {
    this.loadingStudents = true;
    this.adminData.getBatchById(this.selectedBatch).subscribe({
      next: (r: any) => {
        this.students = r.data?.students || [];
        // initialise all to 'present'
        this.markStatus = {};
        this.students.forEach((s: any) => this.markStatus[s.id] = 'present');
        this.loadingStudents = false;
      },
      error: () => this.loadingStudents = false
    });
  }

  markAll(status: 'present' | 'absent' | 'late') {
    this.students.forEach((s: any) => this.markStatus[s.id] = status);
  }

  submitAttendance() {
    if (!this.selectedBatch || !this.markDate || this.students.length === 0) return;
    if (this.markDateOutOfRange) {
      this.saveError = `Selected date is outside the batch period (${this.batchMinDate} – ${this.batchMaxDate}).`;
      return;
    }
    this.saving = true; this.saveError = ''; this.saveSuccess = false;

    const records = this.students.map((s: any) => ({
      student: s.id,
      status: this.markStatus[s.id] || 'absent'
    }));

    this.adminData.markAttendance({
      batch:   this.selectedBatch,
      date:    this.markDate,
      subject: this.markSubject,
      records
    }).subscribe({
      next: () => {
        this.saving = false;
        this.saveSuccess = true;
        this.loadRecords();
        // Jump to view tab so admin can see the saved/updated record
        this.activeTab = 'view';
      },
      error: (e: any) => {
        this.saveError = e.error?.message || 'Failed to save attendance. Please try again.';
        this.saving = false;
      }
    });
  }

  /** Total count of a status for a given attendance session */
  countStatus(session: any, status: string): number {
    return (session.records || []).filter((r: any) => r.status === status).length;
  }

  statusKeys(): string[] { return Object.keys(this.markStatus); }
}
