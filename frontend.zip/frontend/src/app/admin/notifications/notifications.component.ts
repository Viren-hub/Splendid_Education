import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notifications: any[] = [];
  batches: any[] = [];
  loading = true;
  showForm = false;
  form!: FormGroup;
  saving = false;
  error = '';

  constructor(private adminData: AdminDataService, private fb: FormBuilder) {}

  ngOnInit() {
    this.form = this.fb.group({
      title: ['', Validators.required],
      message: ['', Validators.required],
      type: ['general'],
      target: ['all'],
      batchId: ['']
    });
    this.loadNotifications();
    this.loadBatches();
  }

  loadBatches() {
    this.adminData.getBatches().subscribe({
      next: (r: any) => { this.batches = r.data || []; },
      error: () => {}
    });
  }

  get isBatchTarget(): boolean {
    return this.form.get('target')?.value === 'batch';
  }

  loadNotifications() {
    this.loading = true;
    this.adminData.getAllNotifications().subscribe({
      next: (r: any) => { this.notifications = r.data || []; this.loading = false; },
      error: () => { this.error = 'Failed to load notifications.'; this.loading = false; }
    });
  }

  openCreate() { this.showForm = true; }
  closeForm() { this.showForm = false; }

  save() {
    if (this.form.invalid) return;
    this.saving = true;
    const v = this.form.value;
    const payload: any = {
      title: v.title,
      message: v.message,
      type: v.type,
      isGlobal: v.target === 'all',
    };
    if (v.target === 'batch' && v.batchId) {
      payload.batchId = v.batchId;
    }
    this.adminData.createNotification(payload).subscribe({
      next: () => {
        this.saving = false;
        this.showForm = false;
        this.form.reset({ type: 'general', target: 'all', batchId: '' });
        this.loadNotifications();
      },
      error: (err: any) => {
        this.saving = false;
        this.error = err?.error?.errors?.[0]?.msg || 'Failed to send notification.';
      }
    });
  }

  delete(id: string) {
    if (!confirm('Delete this notification?')) return;
    this.adminData.deleteNotification(id).subscribe({ next: () => this.loadNotifications() });
  }

  getIcon(type: string): string {
    const icons: Record<string, string> = {
      fee: 'payments', schedule: 'event', holiday: 'celebration',
      achievement: 'emoji_events', general: 'campaign'
    };
    return icons[type] || 'notifications';
  }
}
