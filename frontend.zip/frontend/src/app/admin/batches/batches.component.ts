import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminDataService } from '../../core/services/admin-data.service';
import { AlertService } from '../../core/services/alert.service';

@Component({
  selector: 'app-admin-batches',
  templateUrl: './batches.component.html',
  styleUrls: ['./batches.component.css'],
})
export class AdminBatchesComponent implements OnInit {
  batches: any[] = [];
  allStudents: any[] = [];

  loading = false;
  errorMsg = '';

  // Batch form modal
  showForm = false;
  editMode = false;
  saving = false;
  formError = '';
  editId = '';
  batchForm!: FormGroup;

  // Delete
  deletingId = '';
  confirmDeleteBatch: { id: string; name: string } | null = null;

  // Student management panel
  managingBatch: any = null;
  loadingStudents = false;
  loadingAllStudents = false;
  allStudentsError = '';
  batchStudents: any[] = [];       // students already in this batch
  studentSearch = '';
  assigningId = '';
  removingId = '';

  readonly DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  readonly GRADES = ['3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];

  constructor(private fb: FormBuilder, private svc: AdminDataService, private alert: AlertService) {}

  trackBatch(_: number, b: any) { return b.id; }
  trackStudent(_: number, s: any) { return s.id; }

  ngOnInit(): void {
    this.loadBatches();
    this.loadAllStudents();
  }

  loadBatches(): void {
    this.loading = true;
    this.errorMsg = '';
    this.svc.getBatches().subscribe({
      next: (r) => { this.batches = r.data || []; this.loading = false; },
      error: (e) => { this.errorMsg = e?.error?.message || 'Failed to load batches'; this.loading = false; },
    });
  }

  loadAllStudents(): void {
    this.loadingAllStudents = true;
    this.allStudentsError = '';
    this.svc.getAllStudents({ limit: '1000' }).subscribe({
      next: (r) => { this.allStudents = r.data || []; this.loadingAllStudents = false; },
      error: () => { this.allStudentsError = 'Failed to load students. Please retry.'; this.loadingAllStudents = false; },
    });
  }

  // ── Form helpers ────────────────────────────────────────
  buildForm(patch?: any): void {
    this.batchForm = this.fb.group({
      batchName:    [patch?.batchName || '', [Validators.required, Validators.minLength(3)]],
      startDate:    [patch?.startDate ? patch.startDate.slice(0, 10) : '', Validators.required],
      endDate:      [patch?.endDate   ? patch.endDate.slice(0, 10)   : ''],
      scheduleTime: [patch?.schedule?.time || ''],
      scheduleDays: [patch?.schedule?.days?.join(',') || ''],
      maxCapacity:  [patch?.maxCapacity || 20, [Validators.required, Validators.min(1)]],
      isActive:     [patch?.isActive ?? true],
      allowedGrades:[patch?.allowedGrades?.join(',') || ''],
    });
  }

  openCreate(): void {
    this.editMode = false;
    this.editId = '';
    this.buildForm();
    this.formError = '';
    this.showForm = true;
  }

  openEdit(b: any): void {
    this.editMode = true;
    this.editId = b.id;
    this.buildForm(b);
    this.formError = '';
    this.showForm = true;
  }

  closeForm(): void { this.showForm = false; }

  isGradeSelected(grade: string): boolean {
    const val = this.batchForm?.value?.allowedGrades || '';
    return val.split(',').includes(grade);
  }

  toggleGrade(grade: string): void {
    const current = this.batchForm.value.allowedGrades
      ? this.batchForm.value.allowedGrades.split(',').filter(Boolean)
      : [];
    const idx = current.indexOf(grade);
    if (idx >= 0) current.splice(idx, 1);
    else current.push(grade);
    this.batchForm.patchValue({ allowedGrades: current.join(',') });
  }

  toggleDay(day: string): void {
    const current = this.batchForm.value.scheduleDays
      ? this.batchForm.value.scheduleDays.split(',').filter(Boolean)
      : [];
    const idx = current.indexOf(day);
    if (idx >= 0) current.splice(idx, 1);
    else current.push(day);
    this.batchForm.patchValue({ scheduleDays: current.join(',') });
  }

  isDaySelected(day: string): boolean {
    const val = this.batchForm?.value?.scheduleDays || '';
    return val.split(',').includes(day);
  }

  save(): void {
    if (this.batchForm.invalid) { this.batchForm.markAllAsTouched(); return; }
    this.saving = true;
    this.formError = '';

    const v = this.batchForm.value;
    const payload: any = {
      batchName:    v.batchName,
      startDate:    v.startDate,
      endDate:      v.endDate || undefined,
      maxCapacity:  v.maxCapacity,
      isActive:     v.isActive,
      allowedGrades: v.allowedGrades ? v.allowedGrades.split(',').filter(Boolean) : [],
      schedule: {
        days: v.scheduleDays ? v.scheduleDays.split(',').filter(Boolean) : [],
        time: v.scheduleTime || '',
      },
    };

    const req$ = this.editMode
      ? this.svc.updateBatch(this.editId, payload)
      : this.svc.createBatch(payload);

    req$.subscribe({
      next: () => { this.saving = false; this.showForm = false; this.loadBatches(); },
      error: (e) => { this.formError = e?.error?.message || 'Save failed'; this.saving = false; },
    });
  }

  deleteBatch(id: string, name: string): void {
    this.confirmDeleteBatch = { id, name };
  }

  confirmDelete(): void {
    if (!this.confirmDeleteBatch) return;
    const { id } = this.confirmDeleteBatch;
    this.deletingId = id;
    this.confirmDeleteBatch = null;
    this.svc.deleteBatch(id).subscribe({
      next: () => { this.deletingId = ''; this.batches = this.batches.filter(b => b.id !== id); },
      error: (e) => { this.alert.show(e?.error?.message || 'Delete failed'); this.deletingId = ''; },
    });
  }

  cancelDelete(): void {
    this.confirmDeleteBatch = null;
  }

  toggleActive(b: any): void {
    this.svc.updateBatch(b.id, { isActive: !b.isActive }).subscribe({
      next: () => { b.isActive = !b.isActive; },
    });
  }

  // ── Student management ───────────────────────────────────
  openManage(b: any): void {
    this.managingBatch = b;
    this.studentSearch = '';
    this.loadBatchStudents(b.id);
    this.loadAllStudents();
  }

  closeManage(): void { this.managingBatch = null; }

  loadBatchStudents(batchId: string): void {
    this.loadingStudents = true;
    this.svc.getBatchById(batchId).subscribe({
      next: (r) => { this.batchStudents = r.data.students || []; this.loadingStudents = false; },
      error: () => { this.batchStudents = []; this.loadingStudents = false; },
    });
  }

  get enrolledIds(): Set<string> {
    return new Set(this.batchStudents.map((s: any) => s.id));
  }

  get searchedStudents(): any[] {
    const q = this.studentSearch.toLowerCase().trim();
    return this.allStudents.filter(s => {
      const name: string = s.user?.name || '';
      const id: string   = s.studentId || '';
      return (name.toLowerCase().includes(q) || id.toLowerCase().includes(q));
    });
  }

  get unassignedStudents(): any[] {
    const allowedGrades: string[] = this.managingBatch?.allowedGrades || [];
    return this.searchedStudents.filter(s => {
      if (this.enrolledIds.has(s.id)) return false;
      // Student already enrolled in a different batch — exclude
      if (s.enrolledBatches && s.enrolledBatches.length > 0) return false;
      // If batch has grade restrictions, only show matching students
      // Students with N/A grade are always eligible (no grade assigned yet)
      if (allowedGrades.length > 0 && s.grade && s.grade !== 'N/A' && !allowedGrades.includes(s.grade)) return false;
      return true;
    });
  }

  assignStudent(studentId: string): void {
    if (!this.managingBatch) return;
    this.assigningId = studentId;
    this.svc.assignStudentToBatch(this.managingBatch.id, studentId).subscribe({
      next: () => {
        this.assigningId = '';
        this.loadBatchStudents(this.managingBatch.id);
        // update card count in list
        const card = this.batches.find(b => b.id === this.managingBatch.id);
        if (card) card.enrolledCount = (card.enrolledCount || 0) + 1;
      },
      error: (e) => { this.alert.show(e?.error?.message || 'Assign failed'); this.assigningId = ''; },
    });
  }

  removeStudent(studentId: string): void {
    if (!this.managingBatch) return;
    this.removingId = studentId;
    this.svc.removeStudentFromBatch(this.managingBatch.id, studentId).subscribe({
      next: () => {
        this.removingId = '';
        this.batchStudents = this.batchStudents.filter(s => s.id !== studentId);
        const card = this.batches.find(b => b.id === this.managingBatch.id);
        if (card) card.enrolledCount = Math.max(0, (card.enrolledCount || 1) - 1);
      },
      error: (e) => { this.alert.show(e?.error?.message || 'Remove failed'); this.removingId = ''; },
    });
  }

  // ── Helpers ──────────────────────────────────────────────
  courseLabel(b: any): string { return b.batchName || '—'; }

  daysLabel(b: any): string {
    return b.schedule?.days?.join(', ') || '—';
  }

  capacityColor(b: any): string {
    const ratio = (b.enrolledCount || 0) / (b.maxCapacity || 1);
    if (ratio >= 1) return 'full';
    if (ratio >= 0.8) return 'warn';
    return 'ok';
  }
}
