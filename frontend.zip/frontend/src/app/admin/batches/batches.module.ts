import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AdminBatchesComponent } from './batches.component';

@NgModule({
  declarations: [AdminBatchesComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: AdminBatchesComponent }]),
  ],
})
export class BatchesModule {}
