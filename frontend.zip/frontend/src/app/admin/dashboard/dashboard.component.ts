import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { TokenService } from '../../core/services/token.service';
import { AdminDataService } from '../../core/services/admin-data.service';

const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  user: any = null;
  stats: any = null;
  loading = true;
  today = new Date();

  // Built from monthlyRevenue for the bar chart
  revenueChart: { month: string; amount: number; pct: number }[] = [];
  // Built from courseDistribution for the donut-style bars
  courseChart: { name: string; count: number; pct: number; color: string }[] = [];

  private courseColors = ['#7c3aed','#2563eb','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#0ea5e9'];

  constructor(
    private authService: AuthService,
    private tokenService: TokenService,
    private adminData: AdminDataService
  ) {}

  ngOnInit(): void {
    this.user = this.tokenService.getUser();
    this.adminData.getDashboardStats().subscribe({
      next: (res: any) => {
        this.stats = res.data;
        this.buildCharts();
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  private buildCharts(): void {
    // ── Revenue bar chart (last 6 months) ──────────────────
    const revenue: any[] = this.stats.monthlyRevenue ?? [];
    const now = new Date();
    const months: { month: string; amount: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const found = revenue.find(r => r.year === d.getFullYear() && r.month === d.getMonth() + 1);
      months.push({ month: MONTH_NAMES[d.getMonth()], amount: found ? found.total : 0 });
    }
    const maxRev = Math.max(...months.map(m => m.amount), 1);
    this.revenueChart = months.map(m => ({ ...m, pct: Math.round((m.amount / maxRev) * 100) }));

    // ── Grade distribution bars ─────────────────────────────
    const dist: any[] = this.stats.courseDistribution ?? [];
    const totalInCourses = dist.reduce((s: number, c: any) => s + c.count, 0) || 1;
    this.courseChart = dist.slice(0, 8).map((c: any, i: number) => ({
      name: c.courseName || 'Unassigned',
      count: c.count,
      pct: Math.round((c.count / totalInCourses) * 100),
      color: this.courseColors[i % this.courseColors.length],
    }));
  }

  /** Trend helpers — use stats.trends from backend */
  trendLabel(val: number): string {
    if (val == null) return 'vs last month';
    if (val > 0) return `+${val}% vs last month`;
    if (val < 0) return `${val}% vs last month`;
    return 'Same as last month';
  }

  /** For attendance the value is pp (percentage points), not % */
  attendanceTrendLabel(val: number): string {
    if (val == null) return 'vs last 30 days';
    if (val > 0) return `+${val}pp vs last 30 days`;
    if (val < 0) return `${val}pp vs last 30 days`;
    return 'Same as last 30 days';
  }

  /** 'up' when positive, 'down' when negative — for pending fees invert (less pending = good) */
  trendDir(val: number, invert = false): 'up' | 'down' {
    if (val == null) return 'up';
    const positive = val >= 0;
    return (invert ? !positive : positive) ? 'up' : 'down';
  }

  trendIcon(val: number, invert = false): string {
    return this.trendDir(val, invert) === 'up' ? 'trending_up' : 'trending_down';
  }

  /** Format large numbers → ₹1.2L, ₹12.8L */
  formatINR(n: number): string {
    if (!n) return '₹0';
    if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
    if (n >= 1000)   return `₹${(n / 1000).toFixed(1)}K`;
    return `₹${n}`;
  }

  /** Days until due (negative = overdue) */
  dueDays(dueDate: string): number {
    if (!dueDate) return 0;
    const diff = new Date(dueDate).getTime() - Date.now();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }

  dueDaysLabel(dueDate: string): string {
    const d = this.dueDays(dueDate);
    if (d < 0)  return `Overdue by ${Math.abs(d)} day${Math.abs(d) !== 1 ? 's' : ''}`;
    if (d === 0) return 'Due today';
    return `Due in ${d} day${d !== 1 ? 's' : ''}`;
  }

  dueSeverity(dueDate: string): string {
    const d = this.dueDays(dueDate);
    if (d < 0)   return 'overdue';
    if (d === 0) return 'today';
    return 'soon';
  }

  /** Only alerts due within the next 10 days (or already overdue) */
  get filteredFeeAlerts(): any[] {
    return (this.stats?.pendingFeeAlerts ?? []).filter((f: any) => this.dueDays(f.dueDate) <= 10);
  }

  logout(): void { this.authService.logout(); }
}


