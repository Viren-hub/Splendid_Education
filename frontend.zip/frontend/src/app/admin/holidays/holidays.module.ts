import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { HolidaysComponent } from './holidays.component';

@NgModule({
  declarations: [HolidaysComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: HolidaysComponent }]),
  ],
})
export class HolidaysModule {}
