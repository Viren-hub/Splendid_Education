import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-holidays',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.css']
})
export class HolidaysComponent implements OnInit {
  holidays: any[] = [];
  loading = true;
  showForm = false;
  editMode = false;
  editId = '';
  form!: FormGroup;
  saving = false;
  error = '';
  today = new Date().toISOString().substring(0, 10);

  constructor(private adminData: AdminDataService, private fb: FormBuilder) {}

  ngOnInit() { this.initForm(); this.loadHolidays(); }

  initForm(h?: any) {
    this.form = this.fb.group({
      name: [h?.name || h?.title || '', Validators.required],
      date: [h?.date ? h.date.substring(0, 10) : '', Validators.required],
      type: [h?.type || 'public_holiday', Validators.required],
      description: [h?.description || '']
    });
  }

  loadHolidays() {
    this.loading = true;
    this.adminData.getHolidays(new Date().getFullYear()).subscribe({
      next: (r: any) => {
        const today = new Date(); today.setHours(0, 0, 0, 0);
        this.holidays = (r.data || [])
          .map((h: any) => ({ ...h, name: h.name || h.title }))
          .filter((h: any) => new Date(h.date) >= today);
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  openCreate() { this.editId = ''; this.editMode = false; this.initForm(); this.showForm = true; }
  edit(h: any) { this.editId = h.id; this.editMode = true; this.initForm(h); this.showForm = true; }
  closeForm() { this.showForm = false; }

  save() {
    if (this.form.invalid) return;
    this.saving = true;
    const payload = { ...this.form.value, title: this.form.value.name };
    const obs = this.editMode
      ? this.adminData.updateHoliday(this.editId, payload)
      : this.adminData.createHoliday(payload);
    obs.subscribe({
      next: () => { this.saving = false; this.showForm = false; this.loadHolidays(); },
      error: () => { this.saving = false; }
    });
  }

  delete(id: string) {
    if (!confirm('Delete this holiday?')) return;
    this.adminData.deleteHoliday(id).subscribe({ next: () => this.loadHolidays() });
  }
}
