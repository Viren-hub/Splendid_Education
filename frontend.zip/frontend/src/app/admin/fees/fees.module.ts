import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { FeesComponent } from './fees.component';

@NgModule({
  declarations: [FeesComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: FeesComponent }]),
  ],
})
export class FeesModule {}
