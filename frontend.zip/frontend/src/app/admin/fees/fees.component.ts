import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-fees',
  templateUrl: './fees.component.html',
  styleUrls: ['./fees.component.css']
})
export class FeesComponent implements OnInit {
  fees: any[] = [];
  stats: any = null;
  loading = true;
  selectedFee: any = null;
  payments: any[] = [];
  paymentForm!: FormGroup;
  showPaymentForm = false;
  saving = false;
  statusFilter = '';

  // Edit fee record
  editFee: any = null;
  editFeeForm!: FormGroup;
  savingEdit = false;
  editFeeError = '';

  paymentError = '';

  constructor(private adminData: AdminDataService, private fb: FormBuilder) {}

  trackFee(_: number, f: any) { return f.id; }
  trackPayment(_: number, p: any) { return p.id; }

  private discountNotExceedTotal(): ValidatorFn {
    return (group: AbstractControl): ValidationErrors | null => {
      const total    = parseFloat(group.get('totalFee')?.value) || 0;
      const discount = parseFloat(group.get('discount')?.value) || 0;
      return discount > total ? { discountExceedsTotal: true } : null;
    };
  }

  ngOnInit() {
    this.paymentForm = this.fb.group({
      amount: [0, [Validators.required, Validators.min(1)]],
      method: ['cash'],
      notes: ['']
    });
    this.editFeeForm = this.fb.group({
      totalFee: [0, [Validators.required, Validators.min(0)]],
      discount:  [0, [Validators.min(0)]],
      dueDate:   ['']
    }, { validators: this.discountNotExceedTotal() });
    this.loadFees();
    this.adminData.getFeeStats().subscribe({ next: (r: any) => this.stats = r.data });
  }

  loadFees() {
    this.loading = true;
    this.adminData.getAllFees({ status: this.statusFilter }).subscribe({
      next: (r: any) => { this.fees = r.data || []; this.loading = false; },
      error: () => this.loading = false
    });
  }

  openPayments(fee: any) {
    this.selectedFee = fee;
    this.showPaymentForm = false;
    this.paymentError = '';
    this.editFee = null;
    this.adminData.getPayments(fee.id).subscribe({ next: (r: any) => this.payments = r.data || [] });
  }

  openEditFee(fee: any) {
    this.editFeeError = '';
    this.editFee = fee;
    this.selectedFee = null;
    const dueDateVal = fee.dueDate ? new Date(fee.dueDate).toISOString().split('T')[0] : '';
    this.editFeeForm.patchValue({
      totalFee: fee.totalFee || 0,
      discount:  fee.discount || 0,
      dueDate:   dueDateVal
    });
  }

  saveEditFee() {
    if (this.editFeeForm.invalid) return;
    this.savingEdit = true;
    const val = this.editFeeForm.value;
    const payload: any = {
      totalFee: val.totalFee,
      discount:  val.discount || 0
    };
    if (val.dueDate) payload.dueDate = val.dueDate;

    this.adminData.updateFee(this.editFee.id, payload).subscribe({
      next: (r: any) => {
        this.savingEdit = false;
        this.editFeeError = '';
        this.editFee = null;
        this.loadFees();
        this.adminData.getFeeStats().subscribe({ next: (res: any) => this.stats = res.data });
      },
      error: (e: any) => {
        this.editFeeError = e?.error?.message || 'Failed to update fee. Please try again.';
        this.savingEdit = false;
      }
    });
  }

  addPayment() {
    if (this.paymentForm.invalid) return;
    this.saving = true;
    this.paymentError = '';
    this.adminData.addPayment(this.selectedFee.id, this.paymentForm.value).subscribe({
      next: () => {
        this.saving = false;
        this.paymentError = '';
        this.showPaymentForm = false;
        this.adminData.getPayments(this.selectedFee.id).subscribe({ next: (r: any) => this.payments = r.data || [] });
        this.loadFees();
      },
      error: (e: any) => {
        this.paymentError = e?.error?.message || 'Failed to record payment. Please try again.';
        this.saving = false;
      }
    });
  }

  /** Count of records for a given status from stats */
  getStatusCount(status: string): number {
    if (!this.stats) return 0;
    return this.stats.byStatus?.find((s: any) => s.status === status)?.count ?? this.stats[status] ?? 0;
  }

  /** Outstanding balance for a given status */
  getStatusBalance(status: string): number {
    if (!this.stats?.byStatus) return 0;
    const row = this.stats.byStatus.find((s: any) => s.status === status);
    if (!row) return 0;
    return Math.max((row.totalAmount ?? 0) - (row.collected ?? 0), 0);
  }

  /** Total amount paid (collected) for a given status */
  getStatusCollected(status: string): number {
    if (!this.stats?.byStatus) return 0;
    return this.stats.byStatus.find((s: any) => s.status === status)?.collected ?? 0;
  }
}
