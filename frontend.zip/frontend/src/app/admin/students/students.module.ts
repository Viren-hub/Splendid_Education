import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { StudentsComponent } from './students.component';

@NgModule({
  declarations: [StudentsComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: StudentsComponent }]),
  ],
})
export class StudentsModule {}
