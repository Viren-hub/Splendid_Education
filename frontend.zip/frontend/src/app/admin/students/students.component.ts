import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { AdminDataService } from '../../core/services/admin-data.service';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit, OnDestroy {
  students: any[] = [];
  loading = true;
  showForm = false;
  editMode = false;
  selectedId = '';
  searchTerm = '';
  private searchSubject = new Subject<string>();
  private destroy$ = new Subject<void>();
  form!: FormGroup;
  saving = false;
  error = '';

  // Delete confirmation
  deleteId = '';
  deleteName = '';
  showDeleteModal = false;
  deleting = false;

  // Reset password
  showResetModal = false;
  resetStudentId = '';
  resetStudentName = '';
  resetNewPassword = '';
  resetting = false;
  resetError = '';
  resetSuccess = false;

  // Detail drawer
  detailStudent: any = null;
  detailOverview: any = null;
  detailOverviewLoading = false;
  formTab = 'student'; // 'student' | 'parent'

  readonly gradeOptions = ['3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];

  readonly emergencyRelationOptions = ['Father', 'Mother', 'Brother', 'Sister', 'Guardian', 'Uncle', 'Aunt', 'Other'];

  readonly academicYearOptions = (() => {
    const years: string[] = [];
    const base = new Date().getFullYear();
    for (let y = base - 1; y <= base + 2; y++) {
      years.push(`${y}-${String(y + 1).slice(-2)}`);
    }
    return years;
  })();

  constructor(private adminData: AdminDataService, private fb: FormBuilder) {}

  trackStudent(_: number, s: any) { return s.id; }

  ngOnInit() {
    this.initForm();
    this.loadStudents();
    this.searchSubject.pipe(
      debounceTime(350),
      distinctUntilChanged(),
      takeUntil(this.destroy$)
    ).subscribe(() => this.loadStudents());
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  onSearchInput() {
    this.searchSubject.next(this.searchTerm);
  }

  initForm(data?: any) {
    this.formTab = 'student';
    const fullName = data?.user?.name || '';
    const spaceIdx = fullName.indexOf(' ');
    const firstName = spaceIdx > -1 ? fullName.substring(0, spaceIdx) : fullName;
    const lastName  = spaceIdx > -1 ? fullName.substring(spaceIdx + 1) : '';

    const phonePattern = Validators.pattern(/^[0-9]{10}$/);

    this.form = this.fb.group({
      firstName: [firstName, Validators.required],
      lastName:  [lastName,  Validators.required],
      contactEmail: [data?.contactEmail || '', [Validators.email]],
      password: ['', this.editMode ? [] : [Validators.required, Validators.minLength(8)]],
      phone: [data?.phone || '', [phonePattern]],
      academicYear: [data?.academicYear || ''],
      grade: [data?.grade || ''],
      // Parent / Guardian
      parentName:  [data?.parentName  || '', Validators.required],
      parentPhone: [data?.parentPhone || '', [Validators.required, phonePattern]],
      emergencyContactRelation: [data?.emergencyContactRelation || ''],
      emergencyContact: [data?.emergencyContact || '', Validators.required],
      // Address & DOB
      address:     [data?.address     || ''],
      dateOfBirth: [data?.dateOfBirth ? new Date(data.dateOfBirth).toISOString().substring(0, 10) : ''],
    });
  }

  openDetail(s: any) {
    this.detailStudent = s;
    this.detailOverview = null;
    this.detailOverviewLoading = true;
    this.adminData.getStudentOverview(s.id).subscribe({
      next: (r: any) => { this.detailOverview = r.data; this.detailOverviewLoading = false; },
      error: () => { this.detailOverviewLoading = false; }
    });
  }
  closeDetail() { this.detailStudent = null; this.detailOverview = null; }

  loadStudents() {
    this.loading = true;
    this.adminData.getAllStudents({ search: this.searchTerm }).subscribe({
      next: (r: any) => { this.students = r.data || []; this.loading = false; },
      error: () => this.loading = false
    });
  }

  openCreate() { this.editMode = false; this.selectedId = ''; this.error = ''; this.initForm(); this.showForm = true; }

  openEdit(s: any) {
    this.editMode = true; this.selectedId = s.id; this.error = ''; this.initForm(s); this.showForm = true;
  }

  save() {
    this.form.markAllAsTouched();
    if (this.form.invalid) {
      const parentTabFields = ['parentName', 'parentPhone', 'emergencyContact', 'emergencyContactRelation', 'address'];
      const studentTabFields = ['firstName', 'lastName', 'contactEmail', 'password', 'phone', 'academicYear', 'grade', 'dateOfBirth'];
      const hasStudentError = studentTabFields.some(f => this.form.get(f)?.invalid);
      const hasParentError  = parentTabFields.some(f => this.form.get(f)?.invalid);
      if (!hasStudentError && hasParentError) {
        this.formTab = 'parent';
        this.error = 'Please fill in the required parent / contact information before saving.';
      }
      return;
    }
    this.saving = true;
    const { firstName, lastName, ...rest } = this.form.value;
    const payload = { ...rest, name: `${firstName.trim()} ${lastName.trim()}` };
    const obs = this.editMode
      ? this.adminData.updateStudent(this.selectedId, payload)
      : this.adminData.createStudent(payload);
    obs.subscribe({
      next: () => { this.saving = false; this.showForm = false; this.loadStudents(); },
      error: (e: any) => {
        this.error = e?.error?.message || e?.message || 'Error saving student. Please try again.';
        this.saving = false;
      }
    });
  }

  delete(id: string) {
    // Kept for compatibility — use openDeleteModal instead
    this.openDeleteModal({ id, user: { name: '' } });
  }

  openDeleteModal(s: any) {
    this.deleteId = s.id;
    this.deleteName = s.user?.name || 'this student';
    this.showDeleteModal = true;
  }

  confirmDelete() {
    if (!this.deleteId) return;
    this.deleting = true;
    this.adminData.deleteStudent(this.deleteId).subscribe({
      next: () => {
        this.deleting = false;
        this.showDeleteModal = false;
        this.deleteId = '';
        this.loadStudents();
      },
      error: () => { this.deleting = false; }
    });
  }

  cancel() { this.showForm = false; this.error = ''; }

  openResetModal(s: any) {
    this.resetStudentId = s.id;
    this.resetStudentName = s.user?.name || 'this student';
    this.resetNewPassword = '';
    this.resetError = '';
    this.resetSuccess = false;
    this.showResetModal = true;
  }

  /** Strips any non-digit character from a phone form control on every keystroke */
  onPhoneInput(event: Event, controlName: string) {
    const input = event.target as HTMLInputElement;
    const digits = input.value.replace(/\D/g, '').slice(0, 10);
    input.value = digits;
    this.form.get(controlName)?.setValue(digits, { emitEvent: false });
    this.form.get(controlName)?.markAsTouched();
  }

  confirmReset() {
    if (!this.resetNewPassword || this.resetNewPassword.length < 8) {
      this.resetError = 'Password must be at least 8 characters.';
      return;
    }
    this.resetting = true;
    this.resetError = '';
    this.adminData.resetStudentPassword(this.resetStudentId, this.resetNewPassword).subscribe({
      next: () => {
        this.resetting = false;
        this.resetSuccess = true;
        setTimeout(() => { this.showResetModal = false; }, 1500);
      },
      error: (e: any) => {
        this.resetError = e?.error?.message || 'Failed to reset password. Please try again.';
        this.resetting = false;
      }
    });
  }
}
