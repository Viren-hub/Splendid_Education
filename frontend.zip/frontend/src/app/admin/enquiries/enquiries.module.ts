import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { EnquiriesComponent } from './enquiries.component';

@NgModule({
  declarations: [EnquiriesComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: EnquiriesComponent }]),
  ],
})
export class EnquiriesModule {}
