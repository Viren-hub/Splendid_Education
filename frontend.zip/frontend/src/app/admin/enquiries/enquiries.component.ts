import { Component, OnInit } from '@angular/core';
import { AdminDataService } from '../../core/services/admin-data.service';
import { LeadCountService } from '../../core/services/lead-count.service';

type EnquiryStatus = '' | 'new' | 'read' | 'replied';

@Component({
  selector: 'app-enquiries',
  templateUrl: './enquiries.component.html',
  styleUrls: ['./enquiries.component.css'],
})
export class EnquiriesComponent implements OnInit {
  enquiries: any[] = [];
  loading = false;
  filterStatus: EnquiryStatus = '';

  activeModal: 'view' | 'delete' | null = null;
  selected: any = null;
  modalStatus = '';
  actionLoading = false;
  actionError = '';

  constructor(
    private adminData: AdminDataService,
    private leadCount: LeadCountService,
  ) {}

  ngOnInit(): void {
    this.leadCount.clearEnquiryCount();
    this.loadEnquiries();
  }

  loadEnquiries(): void {
    this.loading = true;
    this.adminData.getAllContacts().subscribe({
      next: (res: any) => { this.enquiries = res.data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get filtered(): any[] {
    if (!this.filterStatus) return this.enquiries;
    return this.enquiries.filter(e => e.status === this.filterStatus);
  }

  get newCount(): number {
    return this.enquiries.filter(e => e.status === 'new').length;
  }

  setFilter(s: EnquiryStatus): void {
    this.filterStatus = s;
  }

  statusLabel(s: string): string {
    const map: Record<string, string> = { new: 'New', read: 'Read', replied: 'Replied' };
    return map[s] || s;
  }

  statusClass(s: string): string {
    const map: Record<string, string> = { new: 'pill-new', read: 'pill-read', replied: 'pill-replied' };
    return map[s] || '';
  }

  openViewModal(e: any): void {
    this.selected = e;
    this.modalStatus = e.status;
    this.actionError = '';
    this.activeModal = 'view';
    // Auto-mark as read when opened
    if (e.status === 'new') {
      this.adminData.updateContactStatus(e.id, 'read').subscribe({
        next: (res: any) => {
          const idx = this.enquiries.findIndex(x => x.id === e.id);
          if (idx > -1) { this.enquiries[idx] = res.data; this.selected = res.data; this.modalStatus = 'read'; }
        },
      });
    }
  }

  openDeleteModal(e: any): void {
    this.selected = e;
    this.actionError = '';
    this.activeModal = 'delete';
  }

  closeModal(): void {
    this.activeModal = null;
    this.selected = null;
    this.actionError = '';
  }

  saveStatus(): void {
    if (!this.selected) return;
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.updateContactStatus(this.selected.id, this.modalStatus).subscribe({
      next: (res: any) => {
        const idx = this.enquiries.findIndex(x => x.id === this.selected.id);
        if (idx > -1) this.enquiries[idx] = res.data;
        this.actionLoading = false;
        this.closeModal();
      },
      error: (err: any) => {
        this.actionError = err?.error?.message || 'Failed to update status.';
        this.actionLoading = false;
      },
    });
  }

  confirmDelete(): void {
    if (!this.selected) return;
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.deleteContact(this.selected.id).subscribe({
      next: () => {
        this.enquiries = this.enquiries.filter(e => e.id !== this.selected.id);
        this.actionLoading = false;
        this.closeModal();
      },
      error: (err: any) => {
        this.actionError = err?.error?.message || 'Failed to delete enquiry.';
        this.actionLoading = false;
      },
    });
  }
}
