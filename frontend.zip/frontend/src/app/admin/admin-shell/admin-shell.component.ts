import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { LeadCountService } from '../../core/services/lead-count.service';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-admin-shell',
  templateUrl: './admin-shell.component.html',
  styleUrls: ['./admin-shell.component.css'],
})
export class AdminShellComponent implements OnInit, OnDestroy {
  user: any = null;
  sidebarOpen = false;
  demoCount = 0;
  enquiryCount = 0;
  private subs: Subscription[] = [];

  constructor(
    private auth: AuthService,
    private router: Router,
    private leadCount: LeadCountService,
  ) {}

  ngOnInit() {
    this.subs.push(this.auth.currentUser$.subscribe(u => this.user = u));
    this.subs.push(this.leadCount.demoCount$.subscribe(n => this.demoCount = n));
    this.subs.push(this.leadCount.enquiryCount$.subscribe(n => this.enquiryCount = n));

    // Initial fetch
    this.leadCount.refresh();

    // Auto-close sidebar on route change (mobile) + refresh counts
    this.subs.push(
      this.router.events
        .pipe(filter(e => e instanceof NavigationEnd))
        .subscribe(() => {
          this.sidebarOpen = false;
          this.leadCount.refresh();
        })
    );
  }

  ngOnDestroy() { this.subs.forEach(s => s.unsubscribe()); }

  toggleSidebar(): void { this.sidebarOpen = !this.sidebarOpen; }
  closeSidebar(): void  { this.sidebarOpen = false; }

  showLogoutConfirm = false;

  confirmLogout(): void { this.showLogoutConfirm = true; }
  cancelLogout(): void  { this.showLogoutConfirm = false; }
  doLogout(): void      { this.showLogoutConfirm = false; this.auth.logout(); }
}
