import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminShellComponent } from './admin-shell/admin-shell.component';

const routes: Routes = [
  {
    path: '', component: AdminShellComponent,
    children: [
      { path: '', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule) },
      { path: 'students', loadChildren: () => import('./students/students.module').then(m => m.StudentsModule) },
      { path: 'fees', loadChildren: () => import('./fees/fees.module').then(m => m.FeesModule) },
      { path: 'attendance', loadChildren: () => import('./attendance/attendance.module').then(m => m.AttendanceModule) },
      { path: 'holidays', loadChildren: () => import('./holidays/holidays.module').then(m => m.HolidaysModule) },
      { path: 'expenses', loadChildren: () => import('./expenses/expenses.module').then(m => m.ExpensesModule) },
      { path: 'notifications', loadChildren: () => import('./notifications/notifications.module').then(m => m.NotificationsModule) },
      { path: 'batches', loadChildren: () => import('./batches/batches.module').then(m => m.BatchesModule) },
      { path: 'tests', loadChildren: () => import('./tests/tests.module').then(m => m.TestsModule) },
      { path: 'enrollments', loadChildren: () => import('./enrollments/enrollments.module').then(m => m.EnrollmentsModule) },
      { path: 'student-directory', loadChildren: () => import('./student-directory/student-directory.module').then(m => m.StudentDirectoryModule) },
      { path: 'demo-bookings', loadChildren: () => import('./demo-bookings/demo-bookings.module').then(m => m.DemoBookingsModule) },
      { path: 'enquiries', loadChildren: () => import('./enquiries/enquiries.module').then(m => m.EnquiriesModule) },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {}
