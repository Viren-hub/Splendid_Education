import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { DemoBookingsComponent } from './demo-bookings.component';

@NgModule({
  declarations: [DemoBookingsComponent],
  imports: [
    SharedModule,
    RouterModule.forChild([{ path: '', component: DemoBookingsComponent }]),
  ],
})
export class DemoBookingsModule {}
