import { Component, OnInit } from '@angular/core';
import { AdminDataService } from '../../core/services/admin-data.service';
import { LeadCountService } from '../../core/services/lead-count.service';

type BookingStatus = '' | 'pending' | 'confirmed' | 'cancelled';

@Component({
  selector: 'app-demo-bookings',
  templateUrl: './demo-bookings.component.html',
  styleUrls: ['./demo-bookings.component.css'],
})
export class DemoBookingsComponent implements OnInit {
  bookings: any[] = [];
  loading = false;
  filterStatus: BookingStatus = '';

  activeModal: 'status' | 'delete' | null = null;
  selected: any = null;
  modalStatus = '';
  modalScheduledDate = '';
  actionLoading = false;
  actionError = '';

  constructor(
    private adminData: AdminDataService,
    private leadCount: LeadCountService,
  ) {}

  ngOnInit(): void {
    this.leadCount.clearDemoCount();
    this.loadBookings();
  }

  loadBookings(): void {
    this.loading = true;
    this.adminData.getDemoBookings().subscribe({
      next: (res: any) => { this.bookings = res.data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  get filtered(): any[] {
    if (!this.filterStatus) return this.bookings;
    return this.bookings.filter(b => b.status === this.filterStatus);
  }

  setFilter(s: BookingStatus): void {
    this.filterStatus = s;
  }

  statusLabel(s: string): string {
    const map: Record<string, string> = { pending: 'Pending', confirmed: 'Confirmed', cancelled: 'Cancelled' };
    return map[s] || s;
  }

  statusClass(s: string): string {
    const map: Record<string, string> = { pending: 'pill-pending', confirmed: 'pill-confirmed', cancelled: 'pill-cancelled' };
    return map[s] || '';
  }

  openStatusModal(b: any): void {
    this.selected = b;
    this.modalStatus = b.status;
    this.modalScheduledDate = b.scheduledDate ? b.scheduledDate.substring(0, 10) : '';
    this.actionError = '';
    this.activeModal = 'status';
  }

  openDeleteModal(b: any): void {
    this.selected = b;
    this.actionError = '';
    this.activeModal = 'delete';
  }

  closeModal(): void {
    this.activeModal = null;
    this.selected = null;
    this.actionError = '';
  }

  saveStatus(): void {
    if (!this.selected) return;
    this.actionLoading = true;
    this.actionError = '';
    const payload: any = { status: this.modalStatus };
    if (this.modalScheduledDate) payload.scheduledDate = this.modalScheduledDate;
    this.adminData.updateDemoBookingStatus(this.selected.id, payload).subscribe({
      next: (res: any) => {
        const idx = this.bookings.findIndex(b => b.id === this.selected.id);
        if (idx > -1) this.bookings[idx] = res.data;
        this.actionLoading = false;
        this.closeModal();
      },
      error: (err: any) => {
        this.actionError = err?.error?.message || 'Failed to update status.';
        this.actionLoading = false;
      },
    });
  }

  confirmDelete(): void {
    if (!this.selected) return;
    this.actionLoading = true;
    this.actionError = '';
    this.adminData.deleteDemoBooking(this.selected.id).subscribe({
      next: () => {
        this.bookings = this.bookings.filter(b => b.id !== this.selected.id);
        this.actionLoading = false;
        this.closeModal();
      },
      error: (err: any) => {
        this.actionError = err?.error?.message || 'Failed to delete booking.';
        this.actionLoading = false;
      },
    });
  }
}
