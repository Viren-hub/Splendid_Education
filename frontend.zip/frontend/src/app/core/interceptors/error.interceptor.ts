import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { TokenService } from '../services/token.service';
import { ServerStatusService } from '../services/server-status.service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  // Prevent multiple simultaneous 401s from triggering multiple logouts
  private isLoggingOut = false;

  constructor(
    private router: Router,
    private tokenService: TokenService,
    private serverStatus: ServerStatusService,
  ) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      tap(() => {
        // Each successful response clears the outage counter
        this.serverStatus.recordSuccess();
      }),
      catchError((error: HttpErrorResponse) => {
        let userMessage = 'An unexpected error occurred. Please try again later.';

        // Report to the server-status tracker
        // Only track status-0 (offline) and 5xx (server errors); ignore 4xx (client errors)
        if (error.status === 0 || error.status >= 500) {
          this.serverStatus.recordFailure(error.status);
        } else {
          this.serverStatus.recordSuccess();
        }

        if (error.error instanceof ErrorEvent) {
          // Client-side network error - do NOT log out
          userMessage = 'Network error. Please check your connection.';
        } else {
          switch (error.status) {
            case 0:
              userMessage = 'Cannot connect to server. Please check your connection.';
              break;
            case 400:
              userMessage = error.error?.message || 'Invalid request.';
              break;
            case 401:
              userMessage = error.error?.message || 'Session expired. Please log in again.';
              if (!this.isLoggingOut && this.router.url !== '/login') {
                this.isLoggingOut = true;
                this.tokenService.clear();
                const done = () => { this.isLoggingOut = false; };
                this.router.navigate(['/']).then(done, done);
              }
              break;
            case 403:
              userMessage = 'You do not have permission to perform this action.';
              break;
            case 404:
              userMessage = error.error?.message || 'Resource not found.';
              break;
            case 422:
              userMessage = error.error?.message || 'Validation failed.';
              break;
            case 500:
            default:
              userMessage = 'Server error. Please try again later.';
              break;
          }
        }

        const enrichedError = { ...error, userMessage };
        return throwError(() => enrichedError);
      })
    );
  }
}
