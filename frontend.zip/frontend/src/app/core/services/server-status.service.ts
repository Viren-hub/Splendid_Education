import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type OutageType = 'offline' | 'server_error' | null;

export interface ServerStatus {
  outage: OutageType;
  /** ISO timestamp of when the outage was first detected */
  since: string | null;
}

@Injectable({ providedIn: 'root' })
export class ServerStatusService {
  private readonly _status$ = new BehaviorSubject<ServerStatus>({ outage: null, since: null });
  readonly status$ = this._status$.asObservable();

  /** Number of consecutive failures before declaring an outage */
  private readonly THRESHOLD = 2;
  private consecutiveFailures = 0;

  /** Called by the error interceptor on each HTTP failure */
  recordFailure(status: number): void {
    this.consecutiveFailures++;
    if (this.consecutiveFailures >= this.THRESHOLD) {
      const outageType: OutageType = status === 0 ? 'offline' : 'server_error';
      const current = this._status$.getValue();
      // Only update if not already in outage (preserve original timestamp)
      if (!current.outage) {
        this._status$.next({ outage: outageType, since: new Date().toISOString() });
      }
    }
  }

  /** Called by the error interceptor on each successful HTTP response */
  recordSuccess(): void {
    this.consecutiveFailures = 0;
    const current = this._status$.getValue();
    if (current.outage) {
      this._status$.next({ outage: null, since: null });
    }
  }

  get isDown(): boolean {
    return this._status$.getValue().outage !== null;
  }
}
