import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AdminDataService {
  private api = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // Dashboard
  getDashboardStats(): Observable<any> {
    return this.http.get(`${this.api}/admin/dashboard`);
  }

  // Students
  getAllStudents(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) Object.keys(params).forEach(k => params[k] && (httpParams = httpParams.set(k, params[k])));
    return this.http.get(`${this.api}/students`, { params: httpParams });
  }

  getStudent(id: string): Observable<any> {
    return this.http.get(`${this.api}/students/${id}`);
  }

  getStudentOverview(id: string): Observable<any> {
    return this.http.get(`${this.api}/students/${id}/overview`);
  }

  createStudent(data: any): Observable<any> {
    return this.http.post(`${this.api}/students`, data);
  }

  updateStudent(id: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/students/${id}`, data);
  }

  deleteStudent(id: string): Observable<any> {
    return this.http.delete(`${this.api}/students/${id}`);
  }

  resetStudentPassword(id: string, password: string): Observable<any> {
    return this.http.post(`${this.api}/students/${id}/reset-password`, { newPassword: password });
  }

  getStudentHistory(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) Object.keys(params).forEach(k => params[k] && (httpParams = httpParams.set(k, params[k])));
    return this.http.get(`${this.api}/students/history`, { params: httpParams });
  }

  // Fees
  getAllFees(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) Object.keys(params).forEach(k => params[k] && (httpParams = httpParams.set(k, params[k])));
    return this.http.get(`${this.api}/fees`, { params: httpParams });
  }

  getFeeStats(): Observable<any> {
    return this.http.get(`${this.api}/fees/stats/summary`);
  }

  createFee(data: any): Observable<any> {
    return this.http.post(`${this.api}/fees`, data);
  }

  updateFee(feeId: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/fees/${feeId}`, data);
  }

  addPayment(feeId: string, data: any): Observable<any> {
    return this.http.post(`${this.api}/fees/${feeId}/payments`, data);
  }

  getPayments(feeId: string): Observable<any> {
    return this.http.get(`${this.api}/fees/${feeId}/payments`);
  }

  // Attendance
  markAttendance(data: any): Observable<any> {
    return this.http.post(`${this.api}/attendance`, data);
  }

  updateAttendance(id: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/attendance/${id}`, data);
  }

  getBatchAttendance(batchId: string, params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) Object.keys(params).forEach(k => params[k] && (httpParams = httpParams.set(k, params[k])));
    return this.http.get(`${this.api}/attendance/batch/${batchId}`, { params: httpParams });
  }

  // Expenses
  getAllExpenses(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) Object.keys(params).forEach(k => params[k] && (httpParams = httpParams.set(k, params[k])));
    return this.http.get(`${this.api}/expenses`, { params: httpParams });
  }

  getExpenseTrend(months?: number): Observable<any> {
    const params = months ? `?months=${months}` : '';
    return this.http.get(`${this.api}/expenses/trend${params}`);
  }

  createExpense(data: any): Observable<any> {
    return this.http.post(`${this.api}/expenses`, data);
  }

  updateExpense(id: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/expenses/${id}`, data);
  }

  deleteExpense(id: string): Observable<any> {
    return this.http.delete(`${this.api}/expenses/${id}`);
  }

  // Holidays
  getHolidays(year?: number): Observable<any> {
    const params = year ? `?year=${year}` : '';
    return this.http.get(`${this.api}/holidays${params}`);
  }

  createHoliday(data: any): Observable<any> {
    return this.http.post(`${this.api}/holidays`, data);
  }

  updateHoliday(id: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/holidays/${id}`, data);
  }

  deleteHoliday(id: string): Observable<any> {
    return this.http.delete(`${this.api}/holidays/${id}`);
  }

  // Notifications
  getAllNotifications(): Observable<any> {
    return this.http.get(`${this.api}/notifications/all`);
  }

  createNotification(data: any): Observable<any> {
    return this.http.post(`${this.api}/notifications`, data);
  }

  deleteNotification(id: string): Observable<any> {
    return this.http.delete(`${this.api}/notifications/${id}`);
  }

  // Batches
  getBatches(): Observable<any> {
    return this.http.get(`${this.api}/batches`);
  }

  // Courses
  getCourses(): Observable<any> {
    return this.http.get(`${this.api}/courses`);
  }

  getBatchById(batchId: string): Observable<any> {
    return this.http.get(`${this.api}/batches/${batchId}`);
  }

  createBatch(data: any): Observable<any> {
    return this.http.post(`${this.api}/batches`, data);
  }

  updateBatch(id: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/batches/${id}`, data);
  }

  deleteBatch(id: string): Observable<any> {
    return this.http.delete(`${this.api}/batches/${id}`);
  }

  assignStudentToBatch(batchId: string, studentId: string): Observable<any> {
    return this.http.post(`${this.api}/batches/${batchId}/students`, { studentId });
  }

  removeStudentFromBatch(batchId: string, studentId: string): Observable<any> {
    return this.http.delete(`${this.api}/batches/${batchId}/students/${studentId}`);
  }

  // Quizzes
  getAllQuizzes(): Observable<any> {
    return this.http.get(`${this.api}/quizzes`);
  }

  getQuizAdmin(id: string): Observable<any> {
    return this.http.get(`${this.api}/quizzes/${id}`);
  }

  createQuiz(data: any): Observable<any> {
    return this.http.post(`${this.api}/quizzes`, data);
  }

  updateQuiz(id: string, data: any): Observable<any> {
    return this.http.put(`${this.api}/quizzes/${id}`, data);
  }

  deleteQuiz(id: string): Observable<any> {
    return this.http.delete(`${this.api}/quizzes/${id}`);
  }

  getQuizResults(id: string): Observable<any> {
    return this.http.get(`${this.api}/quizzes/${id}/results`);
  }

  // ── Enrollments ───────────────────────────────────────────
  getAllEnrollments(status?: string): Observable<any> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    return this.http.get(`${this.api}/enrollment`, { params });
  }

  adminEnterUTR(id: string, payload: { utrNumber: string; adminNote?: string }): Observable<any> {
    return this.http.put(`${this.api}/enrollment/${id}/admin-utr`, payload);
  }

  confirmEnrollment(id: string, payload?: any): Observable<any> {
    return this.http.put(`${this.api}/enrollment/${id}/confirm`, payload || {});
  }

  rejectEnrollment(id: string, reason: string): Observable<any> {
    return this.http.put(`${this.api}/enrollment/${id}/reject`, { rejectionReason: reason });
  }

  reopenEnrollment(id: string): Observable<any> {
    return this.http.put(`${this.api}/enrollment/${id}/reopen`, {});
  }

  deleteEnrollment(id: string): Observable<any> {
    return this.http.delete(`${this.api}/enrollment/${id}`);
  }

  // Contacts / Enquiries
  getAllContacts(): Observable<any> {
    return this.http.get(`${this.api}/contact`);
  }

  updateContactStatus(id: string, status: string): Observable<any> {
    return this.http.patch(`${this.api}/contact/${id}/status`, { status });
  }

  deleteContact(id: string): Observable<any> {
    return this.http.delete(`${this.api}/contact/${id}`);
  }

  // Demo Bookings
  getDemoBookings(): Observable<any> {
    return this.http.get(`${this.api}/demo-booking`);
  }

  updateDemoBookingStatus(id: string, payload: { status: string; scheduledDate?: string }): Observable<any> {
    return this.http.patch(`${this.api}/demo-booking/${id}/status`, payload);
  }

  deleteDemoBooking(id: string): Observable<any> {
    return this.http.delete(`${this.api}/demo-booking/${id}`);
  }
}
