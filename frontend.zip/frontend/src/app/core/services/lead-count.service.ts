import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AdminDataService } from './admin-data.service';

const DEMO_KEY     = 'splendid_lastViewedDemo';
const ENQ_KEY      = 'splendid_lastViewedEnquiry';
const COOLDOWN_MS  = 60_000; // refresh at most once per minute

@Injectable({ providedIn: 'root' })
export class LeadCountService {
  private _demoCount$    = new BehaviorSubject<number>(0);
  private _enquiryCount$ = new BehaviorSubject<number>(0);
  private _lastRefresh   = 0;

  readonly demoCount$    = this._demoCount$.asObservable();
  readonly enquiryCount$ = this._enquiryCount$.asObservable();

  constructor(private adminData: AdminDataService) {}

  refresh(): void {
    const now = Date.now();
    if (now - this._lastRefresh < COOLDOWN_MS) return;
    this._lastRefresh = now;

    const lastDemo = localStorage.getItem(DEMO_KEY);
    const lastEnq  = localStorage.getItem(ENQ_KEY);

    this.adminData.getDemoBookings().subscribe({
      next: (res: any) => {
        const bookings: any[] = res.data || [];
        const count = lastDemo
          ? bookings.filter(b => new Date(b.createdAt) > new Date(lastDemo)).length
          : bookings.length;
        this._demoCount$.next(count);
      },
      error: () => {},
    });

    this.adminData.getAllContacts().subscribe({
      next: (res: any) => {
        const contacts: any[] = res.data || [];
        const count = lastEnq
          ? contacts.filter(c => new Date(c.createdAt) > new Date(lastEnq)).length
          : contacts.filter(c => c.status === 'new').length;
        this._enquiryCount$.next(count);
      },
      error: () => {},
    });
  }

  clearDemoCount(): void {
    localStorage.setItem(DEMO_KEY, new Date().toISOString());
    this._demoCount$.next(0);
  }

  clearEnquiryCount(): void {
    localStorage.setItem(ENQ_KEY, new Date().toISOString());
    this._enquiryCount$.next(0);
  }
}
