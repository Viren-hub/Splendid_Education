import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface AlertData {
  message: string;
  type: 'error' | 'success' | 'info';
}

@Injectable({ providedIn: 'root' })
export class AlertService {
  private _alert$ = new Subject<AlertData>();
  readonly alert$ = this._alert$.asObservable();

  show(message: string, type: 'error' | 'success' | 'info' = 'error'): void {
    this._alert$.next({ message, type });
  }
}
