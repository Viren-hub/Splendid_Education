import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PublicDataService {
  private api = environment.apiUrl;

  constructor(private http: HttpClient) {}

  // Courses (public read)
  getCourses(): Observable<any> {
    return this.http.get(`${this.api}/courses`);
  }

  // Contact form
  submitContact(payload: { name: string; email: string; phone?: string; message: string }): Observable<any> {
    return this.http.post(`${this.api}/contact`, payload);
  }

  // Demo booking
  bookDemo(payload: {
    name: string;
    email: string;
    phone: string;
    preferredDate: string;
    course?: string;
    message?: string;
  }): Observable<any> {
    return this.http.post(`${this.api}/demo-booking`, payload);
  }

  // Testimonials
  getTestimonials(): Observable<any> {
    return this.http.get(`${this.api}/testimonials`);
  }

  // Project showcase
  getProjects(): Observable<any> {
    return this.http.get(`${this.api}/projects`);
  }

  // ── Enrollment ────────────────────────────────────────────
  submitEnrollment(payload: {
    studentName: string; email: string; phone: string;
    dateOfBirth?: string; schoolName?: string; className: string; address?: string;
    parentName?: string; parentPhone?: string; relation?: string; alternatePhone?: string;
    bloodGroup?: string; medicalInfo?: string; emergencyContactName?: string;
  }): Observable<any> {
    return this.http.post(`${this.api}/enrollment`, payload);
  }

  submitUTR(enrollmentId: string, utrNumber: string): Observable<any> {
    return this.http.put(`${this.api}/enrollment/${enrollmentId}/utr`, { utrNumber });
  }

  getEnrollmentStatus(enrollmentId: string): Observable<any> {
    return this.http.get(`${this.api}/enrollment/${enrollmentId}/status`);
  }
}
