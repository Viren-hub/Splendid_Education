import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class StudentDataService {
  private api = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getMyProfile(): Observable<any> {
    return this.http.get(`${this.api}/students/me`);
  }

  getMyFee(): Observable<any> {
    return this.http.get(`${this.api}/fees/student/me`);
  }

  getMyPayments(feeId: string): Observable<any> {
    return this.http.get(`${this.api}/fees/${feeId}/payments`);
  }

  getMyAttendance(batchId?: string): Observable<any> {
    const params = batchId ? `?batchId=${batchId}` : '';
    return this.http.get(`${this.api}/attendance/student/me${params}`);
  }

  getHolidays(year?: number): Observable<any> {
    const params = year ? `?year=${year}` : '';
    return this.http.get(`${this.api}/holidays${params}`);
  }

  getUpcomingClasses(): Observable<any> {
    return this.http.get(`${this.api}/students/upcoming-classes`);
  }

  getMyNotifications(): Observable<any> {
    return this.http.get(`${this.api}/notifications`);
  }

  markNotificationRead(id: string): Observable<any> {
    return this.http.put(`${this.api}/notifications/${id}/read`, {});
  }

  markAllNotificationsRead(): Observable<any> {
    return this.http.put(`${this.api}/notifications/read-all`, {});
  }

  // Quizzes
  getMyQuizzes(): Observable<any> {
    return this.http.get(`${this.api}/quizzes/my`);
  }

  getQuizToTake(id: string): Observable<any> {
    return this.http.get(`${this.api}/quizzes/${id}/take`);
  }

  startAttempt(id: string): Observable<any> {
    return this.http.post(`${this.api}/quizzes/${id}/start`, {});
  }

  submitAttempt(id: string, data: { answers: any[]; timeTaken: number }): Observable<any> {
    return this.http.put(`${this.api}/quizzes/${id}/submit`, data);
  }

  getAttemptResult(attemptId: string): Observable<any> {
    return this.http.get(`${this.api}/quizzes/attempt/${attemptId}`);
  }

  // Session / attendance self-check
  getMySession(): Observable<any> {
    return this.http.get(`${this.api}/attendance/session/me`);
  }

  checkIn(): Observable<any> {
    return this.http.post(`${this.api}/attendance/session/check-in`, {});
  }

  checkOut(): Observable<any> {
    return this.http.post(`${this.api}/attendance/session/check-out`, {});
  }
}
