import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import en from '../../../assets/i18n/en.json';
import hi from '../../../assets/i18n/hi.json';
import mr from '../../../assets/i18n/mr.json';

export interface Language {
  code: string;
  label: string;
  flag: string;
}

type TranslationMap = Record<string, Record<string, string>>;

const TRANSLATIONS: Record<string, TranslationMap> = { en, hi, mr };

@Injectable({ providedIn: 'root' })
export class LanguageService {
  private readonly STORAGE_KEY = 'splendid_lang';

  readonly languages: Language[] = [
    { code: 'en', label: 'English',  flag: '🇬🇧' },
    { code: 'hi', label: 'हिंदी',    flag: '🇮🇳' },
    { code: 'mr', label: 'मराठी',    flag: '🚩' }
  ];

  private _current$ = new BehaviorSubject<string>(
    localStorage.getItem(this.STORAGE_KEY) || 'en'
  );
  readonly current$ = this._current$.asObservable();

  setLanguage(code: string): void {
    localStorage.setItem(this.STORAGE_KEY, code);
    this._current$.next(code);
  }

  getCurrentLang(): string { return this._current$.value; }

  getCurrentLanguage(): Language {
    return this.languages.find(l => l.code === this.getCurrentLang()) || this.languages[0];
  }

  /** Resolve a dot-notation key like "NAV.HOME" in the current language */
  translate(key: string): string {
    const lang = this._current$.value;
    const parts = key.split('.');
    if (parts.length !== 2) return key;
    const [section, token] = parts;
    return TRANSLATIONS[lang]?.[section]?.[token]
        ?? TRANSLATIONS['en']?.[section]?.[token]
        ?? key;
  }
}
