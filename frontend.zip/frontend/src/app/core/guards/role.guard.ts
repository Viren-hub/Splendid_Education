import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { TokenService } from '../services/token.service';

export const roleGuard: CanActivateFn = (route, state) => {
  const tokenService = inject(TokenService);
  const router = inject(Router);

  const user = tokenService.getUser();
  const expectedRole: string = route.data?.['role'];

  if (user && user.role === expectedRole) {
    return true;
  }

  // Redirect to appropriate dashboard if already logged in but wrong role
  if (user) {
    return router.createUrlTree([`/${user.role}`]);
  }

  return router.createUrlTree(['/login']);
};
