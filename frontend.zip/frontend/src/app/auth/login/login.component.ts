import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  errorMessage = '';
  loading = false;
  showPassword = false;
  private returnUrl = '/';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      loginId:  ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || null;

    // If already authenticated, redirect straight to the correct dashboard
    if (this.authService.isLoggedIn()) {
      const role = this.authService.getRole();
      this.router.navigate([role === 'admin' ? '/admin' : '/student']);
    }
  }

  get loginId()  { return this.loginForm.get('loginId'); }
  get password() { return this.loginForm.get('password'); }

  onSubmit(): void {
    if (this.loginForm.invalid) return;

    this.loading = true;
    this.errorMessage = '';

    this.authService.login(this.loginForm.value).subscribe({
      next: (res) => {
        const role = res.user.role;
        const redirect = this.returnUrl || (role === 'admin' ? '/admin' : '/student');
        this.router.navigateByUrl(redirect);
      },
      error: (err) => {
        this.errorMessage = err?.error?.message || 'Login failed. Please try again.';
        this.loading = false;
      },
    });
  }
}
