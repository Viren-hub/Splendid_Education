import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PublicDataService } from '../../core/services/public-data.service';

type Step = 'details' | 'safety' | 'payment' | 'done';

@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css'],
})
export class EnrollmentComponent implements OnInit {
  step: Step = 'details';

  detailsForm!: FormGroup;
  safetyForm!: FormGroup;
  utrForm!: FormGroup;

  readonly classes = [
    '3rd Class', '4th Class', '5th Class', '6th Class',
    '7th Class', '8th Class', '9th Class', '10th Class (SSC)',
    '11th Class', '12th Class',
  ];
  readonly bloodGroups = ['A+', 'A−', 'B+', 'B−', 'O+', 'O−', 'AB+', 'AB−', 'Not Known'];
  readonly relations  = ['Father', 'Mother', 'Guardian', 'Other'];

  // ── UPI payment details (update these with your actual UPI info) ──
  readonly receiverName = 'Splendid Education';
  readonly upiId        = 'splendid@upi';   // replace with real UPI ID

  enrollmentId = '';
  receiptDate  = '';
  loading = false;
  error = '';
  utrError = '';
  showUtrHelp = false;
  qrError = false;
  submittedUTR = '';

  constructor(private fb: FormBuilder, private publicData: PublicDataService) {}

  ngOnInit(): void {
    this.detailsForm = this.fb.group({
      studentName: ['', [Validators.required, Validators.minLength(2)]],
      dateOfBirth: ['', Validators.required],
      className:   ['', Validators.required],
      schoolName:  [''],
      address:     ['', Validators.required],
    });

    this.safetyForm = this.fb.group({
      parentName:     ['', Validators.required],
      parentPhone:    ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      relation:       ['Father'],
      alternatePhone: ['', Validators.pattern(/^[6-9]\d{9}$/)],
      email:          ['', [Validators.required, Validators.email]],
      phone:          ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      bloodGroup:     ['Not Known'],
    });

    this.utrForm = this.fb.group({
      utrNumber: ['', [Validators.required, Validators.minLength(4)]],
    });
  }

  get d() { return this.detailsForm.controls; }
  get s() { return this.safetyForm.controls; }
  get u() { return this.utrForm.controls; }

  // ── Step 1 → Step 2 ────────────────────────────────────
  nextToSafety(): void {
    if (this.detailsForm.invalid) { this.detailsForm.markAllAsTouched(); return; }
    this.step = 'safety';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  backToDetails(): void { this.step = 'details'; }

  // ── Step 2 → Step 3 ────────────────────────────────────
  submitAll(): void {
    if (this.safetyForm.invalid) { this.safetyForm.markAllAsTouched(); return; }
    this.loading = true;
    this.error   = '';

    const payload = { ...this.detailsForm.value, ...this.safetyForm.value };

    this.publicData.submitEnrollment(payload).subscribe({
      next: (res: any) => {
        this.enrollmentId = res.data?.id;
        this.loading = false;
        this.step = 'payment';
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
      error: (err: any) => {
        this.loading = false;
        if (err.status === 409 && err?.error?.enrollmentId) {
          this.enrollmentId = err.error.enrollmentId;
          this.step = 'payment';
        } else {
          this.error = err?.error?.message || 'Submission failed. Please try again.';
        }
      },
    });
  }

  backToSafety(): void { this.step = 'safety'; }

  // ── Step 3: Submit UTR ──────────────────────────────────
  submitUTR(): void {
    if (this.utrForm.invalid) { this.utrForm.markAllAsTouched(); return; }
    this.loading  = true;
    this.utrError = '';

    this.publicData.submitUTR(this.enrollmentId, this.utrForm.value.utrNumber).subscribe({
      next: () => {
        this.submittedUTR = this.utrForm.value.utrNumber;
        this.receiptDate  = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
        this.loading = false;
        this.step = 'done';
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
      error: (err: any) => {
        this.loading = false;
        this.utrError = err?.error?.message || 'Failed to submit UTR. Please try again.';
      },
    });
  }

  toggleUtrHelp(): void { this.showUtrHelp = !this.showUtrHelp; }

  printReceipt(): void {
    window.print();
  }

  shareOnWhatsApp(): void {
    const msg = encodeURIComponent(
      `📋 *Splendid Education — Enrollment Receipt*\n` +
      `Student : ${this.d['studentName'].value}\n` +
      `Class   : ${this.d['className'].value}\n` +
      `Parent  : ${this.s['parentName'].value}\n` +
      `UTR No  : ${this.submittedUTR}\n` +
      `Ref ID  : ${this.enrollmentId}\n` +
      `Date    : ${this.receiptDate}\n\n` +
      `Payment processed successfully. Login credentials will be shared within 24–48 hours.`
    );
    window.open(`https://wa.me/?text=${msg}`, '_blank');
  }
}
