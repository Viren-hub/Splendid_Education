import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { PublicRoutingModule } from './public-routing.module';
import { SharedModule } from '../shared/shared.module';
import { PublicShellComponent } from './public-shell/public-shell.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { DemoBookingComponent } from './demo-booking/demo-booking.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ProjectShowcaseComponent } from './project-showcase/project-showcase.component';
import { AboutComponent } from './about/about.component';
import { GalleryComponent } from './gallery/gallery.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    PublicShellComponent,
    HomeComponent,
    ContactComponent,
    DemoBookingComponent,
    TestimonialsComponent,
    ProjectShowcaseComponent,
    AboutComponent,
    GalleryComponent,
    EnrollmentComponent,
  ],
  imports: [CommonModule, RouterModule, ReactiveFormsModule, SharedModule, PublicRoutingModule],
})
export class PublicModule {}
