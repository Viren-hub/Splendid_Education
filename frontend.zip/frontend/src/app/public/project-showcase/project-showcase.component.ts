import { Component, OnInit } from '@angular/core';
import { PublicDataService } from '../../core/services/public-data.service';

@Component({
  selector: 'app-project-showcase',
  templateUrl: './project-showcase.component.html',
  styleUrls: ['./project-showcase.component.css'],
})
export class ProjectShowcaseComponent implements OnInit {
  projects: any[] = [];
  loading = true;

  dummyProjects = [
    { title: 'Space Shooter Game', type: 'Game', icon: 'sports_esports', tech: 'Scratch', age: 9, desc: 'A fully playable space shooter with power-ups, enemies, and score tracking.' },
    { title: 'Weather App', type: 'Web App', icon: 'wb_sunny', tech: 'Python', age: 12, desc: 'Shows live weather for any city using a real weather API.' },
    { title: 'My Portfolio Site', type: 'Website', icon: 'web', tech: 'HTML/CSS/JS', age: 14, desc: 'A personal portfolio with a contact form, project gallery, and animations.' },
    { title: 'Quiz Master', type: 'Game', icon: 'quiz', tech: 'Scratch', age: 10, desc: 'A multiplayer quiz game for your class with 50 questions and a leaderboard.' },
    { title: 'Plant Watering Reminder', type: 'App', icon: 'local_florist', tech: 'Python', age: 13, desc: 'A desktop app that sends you reminders to water your plants using a schedule.' },
    { title: 'Animated Story Book', type: 'Animation', icon: 'auto_stories', tech: 'Scratch', age: 7, desc: 'A beautifully illustrated interactive story with character animations and sound.' },
  ];

  constructor(private publicData: PublicDataService) {}

  ngOnInit(): void {
    this.publicData.getProjects().subscribe({
      next: (res: any) => { this.projects = res.data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }

  getProjectIcon(type: string): string {
    if (!type) return 'code';
    const t = type.toLowerCase();
    if (t.includes('game')) return 'sports_esports';
    if (t.includes('web')) return 'web';
    if (t.includes('app')) return 'phone_android';
    if (t.includes('animation')) return 'animation';
    return 'computer';
  }
}
