import { Component, OnInit } from '@angular/core';
import { PublicDataService } from '../../core/services/public-data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  testimonials: any[] = [];

  gradePrograms = [
    { grade: '3rd – 5th Class', icon: 'sports_esports', badge: 'Beginner', desc: 'Fun visual coding with Scratch — create stories, animations and simple games!' },
    { grade: '6th – 7th Class', icon: 'code',           badge: 'Intermediate', desc: 'Introduction to Python programming, logic building and mini-projects.' },
    { grade: '8th – 9th Class', icon: 'web',            badge: 'Advanced', desc: 'Web development with HTML, CSS and JavaScript. Build real websites!' },
    { grade: '10th – 12th Class', icon: 'phone_android', badge: 'Expert', desc: 'App development, advanced Python and project-based learning for boards students.' },
  ];

  dummyTestimonials = [
    { text: 'My daughter built her first game in just 2 months! The teachers are incredibly patient and make coding so much fun.', avatar: 'P', name: 'Priya Sharma', role: 'Parent of Aaradhya, 9' },
    { text: 'Rohan went from zero coding knowledge to building a fully working website in 3 months. Splendid Edu truly lives up to its name!', avatar: 'R', name: 'Rajesh Patel', role: 'Parent of Rohan, 12' },
    { text: `Small batch size means my son gets personal attention. He's more confident and absolutely loves coming to class every week.`, avatar: 'A', name: 'Anjali Mehta', role: 'Parent of Arjun, 11' },
  ];

  constructor(private publicData: PublicDataService) {}

  ngOnInit(): void {
    this.publicData.getTestimonials().subscribe({ next: (r: any) => { this.testimonials = r.data || []; }, error: () => {} });
  }
}
