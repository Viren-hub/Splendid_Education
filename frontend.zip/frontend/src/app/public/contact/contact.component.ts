import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PublicDataService } from '../../core/services/public-data.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
})
export class ContactComponent {
  form: FormGroup;
  loading = false;
  success = false;
  error = '';

  constructor(private fb: FormBuilder, private publicData: PublicDataService) {
    this.form = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: [''],
      message: ['', Validators.required],
    });
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';
    this.publicData.submitContact(this.form.value).subscribe({
      next: () => { this.success = true; this.form.reset(); this.loading = false; },
      error: (err: any) => { this.error = err.userMessage || 'Failed to send message.'; this.loading = false; },
    });
  }
}
