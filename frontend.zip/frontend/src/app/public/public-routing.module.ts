import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PublicShellComponent } from './public-shell/public-shell.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { DemoBookingComponent } from './demo-booking/demo-booking.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ProjectShowcaseComponent } from './project-showcase/project-showcase.component';
import { AboutComponent } from './about/about.component';
import { GalleryComponent } from './gallery/gallery.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';

const routes: Routes = [
  {
    path: '', component: PublicShellComponent,
    children: [
      { path: '', component: HomeComponent },
      { path: 'about', component: AboutComponent },
      { path: 'gallery', component: GalleryComponent },
      { path: 'contact', component: ContactComponent },
      { path: 'book-demo', component: DemoBookingComponent },
      { path: 'testimonials', component: TestimonialsComponent },
      { path: 'projects', component: ProjectShowcaseComponent },
      { path: 'enroll', component: EnrollmentComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PublicRoutingModule {}
