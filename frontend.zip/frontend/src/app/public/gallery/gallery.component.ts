import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent {
  galleryItems = [
    { icon: '💻', label: 'Web Dev Class' },
    { icon: '🤖', label: 'AI Workshop' },
    { icon: '📱', label: 'Mobile App Demo' },
    { icon: '🎮', label: 'Game Dev Session' },
    { icon: '🏆', label: 'Hackathon 2024' },
    { icon: '🎓', label: 'Graduation Ceremony' },
    { icon: '🚀', label: 'Project Launch' },
    { icon: '👨‍💻', label: 'Coding Bootcamp' },
    { icon: '📊', label: 'Data Science Lab' },
    { icon: '🌐', label: 'Full Stack Project' },
    { icon: '🎯', label: 'Interview Prep' },
    { icon: '🤝', label: 'Industry Meetup' },
  ];
}
