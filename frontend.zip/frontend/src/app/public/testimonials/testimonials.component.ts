import { Component, OnInit } from '@angular/core';
import { PublicDataService } from '../../core/services/public-data.service';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.css'],
})
export class TestimonialsComponent implements OnInit {
  testimonials: any[] = [];
  loading = true;

  dummyTestimonials = [
    { text: 'My daughter built her first game in just 2 months! The teachers here are incredibly patient and make coding so much fun.', avatar: 'P', name: 'Priya Sharma', role: 'Parent of Aaradhya, 9' },
    { text: 'Rohan went from zero coding knowledge to building a fully working website. Splendid Edu truly lives up to its name!', avatar: 'R', name: 'Rajesh Patel', role: 'Parent of Rohan, 12' },
    { text: 'Small batch size means my son gets personal attention. Absolutely loves coming to class every week.', avatar: 'A', name: 'Anjali Mehta', role: 'Parent of Arjun, 11' },
    { text: 'The free demo immediately convinced us. Meera became so passionate about coding after just a few weeks!', avatar: 'M', name: 'Meena Gupta', role: 'Parent of Meera, 10' },
    { text: 'Excellent structured curriculum. My son built a real app and presented it on demo day. Incredibly proud moment!', avatar: 'S', name: 'Suresh Kumar', role: 'Parent of Siddharth, 14' },
    { text: 'The teachers are amazing. Very patient and know how to make complex concepts fun and easy for kids.', avatar: 'N', name: 'Nisha Reddy', role: 'Parent of Navya, 8' },
  ];

  constructor(private publicData: PublicDataService) {}

  ngOnInit(): void {
    this.publicData.getTestimonials().subscribe({
      next: (res: any) => { this.testimonials = res.data || []; this.loading = false; },
      error: () => { this.loading = false; },
    });
  }
}
