import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PublicDataService } from '../../core/services/public-data.service';

@Component({
  selector: 'app-demo-booking',
  templateUrl: './demo-booking.component.html',
  styleUrls: ['./demo-booking.component.css'],
})
export class DemoBookingComponent implements OnInit {
  form: FormGroup;
  loading = false;
  success = false;
  error = '';
  ages = Array.from({ length: 11 }, (_, i) => i + 6); // 6 to 16
  minDate = new Date().toISOString().split('T')[0];

  constructor(private fb: FormBuilder, private publicData: PublicDataService) {
    this.form = this.fb.group({
      parentName: ['', Validators.required],
      childName: ['', Validators.required],
      childAge: ['', Validators.required],
      phone: ['', Validators.required],
      preferredDate: [''],
      interest: [''],
    });
  }

  ngOnInit(): void {}

  submit(): void {
    if (this.form.invalid) return;
    this.loading = true;
    this.error = '';
    this.publicData.bookDemo(this.form.value).subscribe({
      next: () => { this.success = true; this.loading = false; },
      error: (err: any) => { this.error = err.userMessage || 'Failed to book demo. Please call us directly.'; this.loading = false; },
    });
  }
}
