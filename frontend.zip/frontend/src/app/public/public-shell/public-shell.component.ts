import { Component, OnInit, HostListener, ElementRef } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { LanguageService, Language } from '../../core/services/language.service';

@Component({
  selector: 'app-public-shell',
  templateUrl: './public-shell.component.html',
  styleUrls: ['./public-shell.component.css'],
})
export class PublicShellComponent implements OnInit {
  menuOpen = false;
  currentYear = new Date().getFullYear();

  isLoggedIn = false;
  dashboardLink = '/login';
  userName = '';

  // Language
  langDropdownOpen = false;

  constructor(
    public authService: AuthService,
    public langService: LanguageService,
    private eRef: ElementRef
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.isLoggedIn = !!user;
      if (user) {
        this.dashboardLink = user.role === 'admin' ? '/admin' : '/student';
        this.userName = user.name || '';
      } else {
        this.dashboardLink = '/login';
        this.userName = '';
      }
    });
  }

  toggleMenu() { this.menuOpen = !this.menuOpen; }
  closeMenu()  { this.menuOpen = false; }

  toggleLangDropdown()  { this.langDropdownOpen = !this.langDropdownOpen; }
  closeLangDropdown()   { this.langDropdownOpen = false; }

  selectLanguage(lang: Language): void {
    this.langService.setLanguage(lang.code);
    this.langDropdownOpen = false;
  }

  @HostListener('document:click', ['$event'])
  onOutsideClick(event: Event): void {
    if (!this.eRef.nativeElement.querySelector('.lang-selector')?.contains(event.target)) {
      this.langDropdownOpen = false;
    }
  }

  showLogoutConfirm = false;

  logout(): void        { this.showLogoutConfirm = true; }
  cancelLogout(): void  { this.showLogoutConfirm = false; }
  doLogout(): void      { this.showLogoutConfirm = false; this.menuOpen = false; this.authService.logout(); }
}
