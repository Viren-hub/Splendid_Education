import { Pipe, PipeTransform, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { LanguageService } from '../core/services/language.service';

@Pipe({ name: 'translate', pure: false })
export class TranslatePipe implements PipeTransform, OnDestroy {
  private sub: Subscription;

  constructor(
    private langService: LanguageService,
    private cdr: ChangeDetectorRef
  ) {
    // Re-render the pipe whenever the language changes
    this.sub = this.langService.current$.subscribe(() => this.cdr.markForCheck());
  }

  transform(key: string): string {
    return this.langService.translate(key);
  }

  ngOnDestroy(): void { this.sub.unsubscribe(); }
}
