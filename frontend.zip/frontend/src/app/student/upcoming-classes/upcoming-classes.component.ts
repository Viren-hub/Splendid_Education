import { Component, OnInit } from '@angular/core';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-upcoming-classes',
  templateUrl: './upcoming-classes.component.html',
  styleUrls: ['./upcoming-classes.component.css']
})
export class UpcomingClassesComponent implements OnInit {
  classes: any[] = [];
  loading = true;

  constructor(private studentData: StudentDataService) {}

  ngOnInit() {
    this.studentData.getUpcomingClasses().subscribe({
      next: (res: any) => { this.classes = res.data || []; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  getDayClass(index: number): string {
    const colors = ['day--purple', 'day--blue', 'day--teal', 'day--green', 'day--orange', 'day--pink', 'day--red'];
    return colors[index % colors.length];
  }

  isToday(dateStr: string): boolean {
    if (!dateStr) return false;
    const d = new Date(dateStr);
    const t = new Date();
    return d.getFullYear() === t.getFullYear() &&
           d.getMonth() === t.getMonth() &&
           d.getDate() === t.getDate();
  }

  getDayAbbr(day: string): string {
    return day ? day.substring(0, 3).toUpperCase() : '---';
  }

  getDateNum(dateStr: string): string {
    if (!dateStr) return '--';
    return new Date(dateStr).getDate().toString();
  }

  getMonthAbbr(dateStr: string): string {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('en-IN', { month: 'short' });
  }
}
