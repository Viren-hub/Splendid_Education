import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FeeStatusComponent } from './fee-status/fee-status.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { HolidaysComponent } from './holidays/holidays.component';
import { UpcomingClassesComponent } from './upcoming-classes/upcoming-classes.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { StudentTestsComponent } from './tests/tests.component';
import { TakeTestComponent } from './take-test/take-test.component';
import { TestResultComponent } from './test-result/test-result.component';

const routes: Routes = [
  {
    path: '', component: DashboardComponent,
    children: [
      { path: 'fee', component: FeeStatusComponent },
      { path: 'attendance', component: AttendanceComponent },
      { path: 'holidays', component: HolidaysComponent },
      { path: 'upcoming', component: UpcomingClassesComponent },
      { path: 'notifications', component: NotificationsComponent },
      { path: 'tests', component: StudentTestsComponent },
      { path: 'take-test/:id', component: TakeTestComponent },
      { path: 'test-result/:attemptId', component: TestResultComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class StudentRoutingModule {}
