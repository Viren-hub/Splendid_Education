import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentDataService } from '../../core/services/student-data.service';

const MAX_VIOLATIONS = 3;

@Component({
  selector: 'app-take-test',
  templateUrl: './take-test.component.html',
  styleUrls: ['./take-test.component.css']
})
export class TakeTestComponent implements OnInit, OnDestroy {
  quizId = '';
  quiz: any = null;
  attemptId = '';
  loading = true;
  submitting = false;
  error = '';

  // Test state
  currentIndex = 0;
  answers: { questionId: string; selectedOption: string | null }[] = [];
  startedAt = 0;

  // Timer
  timeLeft = 0;
  timerInterval: any = null;

  // ── Anti-cheat ──────────────────────────────────────────
  testStarted = false;              // true after instructions dismissed
  violationCount = 0;
  maxViolations = MAX_VIOLATIONS;
  showWarning = false;
  warningMessage = '';
  warningDismissTimer: any = null;

  // ── Timer warnings ──────────────────────────────────────
  showTimerWarning = false;
  timerWarningMessage = '';
  timerWarningLevel: 'warn' | 'danger' = 'warn';   // 'warn' = 15 min, 'danger' = 5 min
  private warned15 = false;
  private warned5 = false;
  timerWarningDismissTimer: any = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private studentData: StudentDataService
  ) {}

  ngOnInit() {
    this.quizId = this.route.snapshot.paramMap.get('id') || '';
    this.initTest();
  }

  ngOnDestroy() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    if (this.warningDismissTimer) clearTimeout(this.warningDismissTimer);
    if (this.timerWarningDismissTimer) clearTimeout(this.timerWarningDismissTimer);
    this.removeAntiCheatListeners();
    this.exitFullscreen();
  }

  // ── Fullscreen helpers ───────────────────────────────────
  requestFullscreen() {
    const el = document.documentElement as any;
    if (el.requestFullscreen) el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    else if (el.mozRequestFullScreen) el.mozRequestFullScreen();
  }

  exitFullscreen() {
    const doc = document as any;
    if (doc.exitFullscreen) doc.exitFullscreen().catch(() => {});
    else if (doc.webkitExitFullscreen) doc.webkitExitFullscreen();
  }

  get isFullscreen(): boolean {
    const doc = document as any;
    return !!(doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement);
  }

  // ── Anti-cheat event listeners ───────────────────────────
  private boundVisibility = this.onVisibilityChange.bind(this);
  private boundFullscreenChange = this.onFullscreenChange.bind(this);
  private boundBlur = this.onWindowBlur.bind(this);

  attachAntiCheatListeners() {
    document.addEventListener('visibilitychange', this.boundVisibility);
    document.addEventListener('fullscreenchange', this.boundFullscreenChange);
    document.addEventListener('webkitfullscreenchange', this.boundFullscreenChange);
    window.addEventListener('blur', this.boundBlur);
  }

  removeAntiCheatListeners() {
    document.removeEventListener('visibilitychange', this.boundVisibility);
    document.removeEventListener('fullscreenchange', this.boundFullscreenChange);
    document.removeEventListener('webkitfullscreenchange', this.boundFullscreenChange);
    window.removeEventListener('blur', this.boundBlur);
  }

  onVisibilityChange() {
    if (!this.testStarted) return;
    if (document.hidden) {
      this.triggerViolation('⚠️ Tab switching is not allowed during the test!');
    }
  }

  onWindowBlur() {
    if (!this.testStarted) return;
    this.triggerViolation('⚠️ Switching windows or apps is not allowed during the test!');
  }

  onFullscreenChange() {
    if (!this.testStarted) return;
    if (!this.isFullscreen) {
      this.triggerViolation('⚠️ You exited fullscreen mode! Please stay in fullscreen.');
      // Re-request fullscreen after a short delay
      setTimeout(() => this.requestFullscreen(), 800);
    }
  }

  // ── Keyboard blocking ─────────────────────────────────────
  @HostListener('document:keydown', ['$event'])
  onKeyDown(e: KeyboardEvent) {
    if (!this.testStarted) return;

    const ctrl = e.ctrlKey || e.metaKey;

    // Block copy, cut, paste, select-all, print, find, save
    if (ctrl && ['c', 'x', 'v', 'a', 'p', 'f', 's', 'u'].includes(e.key.toLowerCase())) {
      e.preventDefault();
      e.stopPropagation();
      if (['c', 'x'].includes(e.key.toLowerCase())) {
        this.triggerViolation('⚠️ Copying or cutting content is strictly prohibited!');
      }
      return false;
    }

    // Block F12 (DevTools), F5 (Refresh), Alt+Tab (can't fully block but warn)
    if (e.key === 'F12' || e.key === 'F5' || (e.altKey && e.key === 'Tab')) {
      e.preventDefault();
      this.triggerViolation('⚠️ This action is not allowed during the test!');
      return false;
    }

    // Block PrintScreen
    if (e.key === 'PrintScreen') {
      e.preventDefault();
      this.triggerViolation('⚠️ Screenshots are not allowed during the test!');
      return false;
    }

    return true;
  }

  // Block right-click
  @HostListener('document:contextmenu', ['$event'])
  onContextMenu(e: MouseEvent) {
    if (!this.testStarted) return;
    e.preventDefault();
    this.triggerViolation('⚠️ Right-click is disabled during the test!');
  }

  // Block copy event
  @HostListener('document:copy', ['$event'])
  onCopy(e: ClipboardEvent) {
    if (!this.testStarted) return;
    e.preventDefault();
    this.triggerViolation('⚠️ Copying content is strictly prohibited!');
  }

  // Block cut event
  @HostListener('document:cut', ['$event'])
  onCut(e: ClipboardEvent) {
    if (!this.testStarted) return;
    e.preventDefault();
    this.triggerViolation('⚠️ Cutting content is not allowed during the test!');
  }

  // Block paste event
  @HostListener('document:paste', ['$event'])
  onPaste(e: ClipboardEvent) {
    if (!this.testStarted) return;
    e.preventDefault();
  }

  // ── Violation handler ────────────────────────────────────
  triggerViolation(message: string) {
    this.violationCount++;
    this.warningMessage = message;
    const remaining = this.maxViolations - this.violationCount;

    if (this.violationCount >= this.maxViolations) {
      this.warningMessage = '🚫 Maximum violations reached! Your test is being auto-submitted.';
      this.showWarning = true;
      setTimeout(() => this.submitTest(true), 2500);
      return;
    }

    this.warningMessage += ` (Warning ${this.violationCount}/${this.maxViolations} — ${remaining} remaining before auto-submit)`;
    this.showWarning = true;

    if (this.warningDismissTimer) clearTimeout(this.warningDismissTimer);
    this.warningDismissTimer = setTimeout(() => {
      this.showWarning = false;
    }, 4000);
  }

  dismissWarning() {
    this.showWarning = false;
    if (this.warningDismissTimer) clearTimeout(this.warningDismissTimer);
  }

  // ── Test initialisation ──────────────────────────────────
  initTest() {
    this.loading = true;
    this.studentData.getQuizToTake(this.quizId).subscribe({
      next: (res: any) => {
        const quizData = res?.data || res;
        this.quiz = quizData;
        this.answers = (quizData.questions || []).map((q: any) => ({
          questionId: q.id,
          selectedOption: null
        }));
        this.studentData.startAttempt(this.quizId).subscribe({
          next: (attemptRes: any) => {
            const attempt = attemptRes?.data || attemptRes;
            this.attemptId = attempt.id;
            this.startedAt = Date.now();
            this.loading = false;
            // Don't start timer yet — wait for instructions dismissed
          },
          error: (err: any) => {
            this.error = err?.error?.message || 'Failed to start test';
            this.loading = false;
          }
        });
      },
      error: (err: any) => {
        this.error = err?.error?.message || 'Failed to load test';
        this.loading = false;
      }
    });
  }

  /** Called when student clicks "I Understand, Start Test" on the instructions screen */
  beginTest() {
    this.testStarted = true;
    this.attachAntiCheatListeners();
    this.requestFullscreen();
    this.startTimer(this.quiz.duration * 60);
  }

  startTimer(seconds: number) {
    this.timeLeft = seconds;
    this.timerInterval = setInterval(() => {
      this.timeLeft--;

      // 15-minute warning
      if (this.timeLeft === 900 && !this.warned15) {
        this.warned15 = true;
        this.showTimerAlert('⏰ 15 minutes remaining! Please pace yourself and review your answers.', 'warn', 8000);
      }

      // 5-minute final warning
      if (this.timeLeft === 300 && !this.warned5) {
        this.warned5 = true;
        this.showTimerAlert('🚨 FINAL WARNING: Only 5 minutes left! Wrap up and submit soon.', 'danger', 10000);
      }

      if (this.timeLeft <= 0) {
        clearInterval(this.timerInterval);
        this.submitTest(true);
      }
    }, 1000);
  }

  showTimerAlert(message: string, level: 'warn' | 'danger', duration: number) {
    if (this.timerWarningDismissTimer) clearTimeout(this.timerWarningDismissTimer);
    this.timerWarningMessage = message;
    this.timerWarningLevel = level;
    this.showTimerWarning = true;
    this.timerWarningDismissTimer = setTimeout(() => {
      this.showTimerWarning = false;
    }, duration);
  }

  dismissTimerWarning() {
    this.showTimerWarning = false;
    if (this.timerWarningDismissTimer) clearTimeout(this.timerWarningDismissTimer);
  }

  get timerDisplay(): string {
    const m = Math.floor(this.timeLeft / 60);
    const s = this.timeLeft % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  get timerClass(): string {
    if (this.timeLeft <= 60) return 'timer-red';
    if (this.timeLeft <= 180) return 'timer-orange';
    return 'timer-green';
  }

  get currentQuestion(): any {
    return this.quiz?.questions?.[this.currentIndex];
  }

  get currentAnswer(): string | null {
    return this.answers[this.currentIndex]?.selectedOption || null;
  }

  get progress(): number {
    const answered = this.answers.filter(a => a.selectedOption !== null).length;
    return this.quiz?.questions?.length ? (answered / this.quiz.questions.length) * 100 : 0;
  }

  get answeredCount(): number {
    return this.answers.filter(a => a.selectedOption !== null).length;
  }

  selectOption(optionId: string) {
    if (this.answers[this.currentIndex]) {
      this.answers[this.currentIndex].selectedOption = optionId;
    }
  }

  goTo(index: number) {
    if (index >= 0 && index < (this.quiz?.questions?.length || 0)) {
      this.currentIndex = index;
    }
  }

  prevQuestion() { this.goTo(this.currentIndex - 1); }
  nextQuestion() { this.goTo(this.currentIndex + 1); }

  isAnswered(index: number): boolean {
    return !!this.answers[index]?.selectedOption;
  }

  submitTest(autoSubmit = false) {
    if (this.submitting) return;
    if (!autoSubmit) {
      const unanswered = this.answers.filter(a => !a.selectedOption).length;
      if (unanswered > 0) {
        const confirmed = confirm(
          `You have ${unanswered} unanswered question(s). Do you still want to submit?`
        );
        if (!confirmed) return;
      }
    }

    if (this.timerInterval) clearInterval(this.timerInterval);
    this.removeAntiCheatListeners();
    this.exitFullscreen();
    this.submitting = true;
    const timeTaken = Math.round((Date.now() - this.startedAt) / 1000);

    this.studentData.submitAttempt(this.quizId, {
      answers: this.answers.map(a => ({ questionId: a.questionId, selectedOptionId: a.selectedOption })),
      timeTaken
    }).subscribe({
      next: (result: any) => {
        this.submitting = false;
        const r = result?.data || result;
        this.router.navigate(['/student/test-result', r.attemptId || r.id]);
      },
      error: (err: any) => {
        this.submitting = false;
        this.error = err?.error?.message || 'Failed to submit test';
      }
    });
  }
}
