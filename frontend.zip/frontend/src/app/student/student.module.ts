import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { StudentRoutingModule } from './student-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SharedModule } from '../shared/shared.module';
import { FeeStatusComponent } from './fee-status/fee-status.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { HolidaysComponent } from './holidays/holidays.component';
import { UpcomingClassesComponent } from './upcoming-classes/upcoming-classes.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { StudentTestsComponent } from './tests/tests.component';
import { TakeTestComponent } from './take-test/take-test.component';
import { TestResultComponent } from './test-result/test-result.component';


@NgModule({
  declarations: [
    DashboardComponent,
    FeeStatusComponent,
    AttendanceComponent,
    HolidaysComponent,
    UpcomingClassesComponent,
    NotificationsComponent,
    StudentTestsComponent,
    TakeTestComponent,
    TestResultComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    StudentRoutingModule,
    SharedModule,
  ],
})
export class StudentModule {}
