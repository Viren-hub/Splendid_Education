import { Component, OnInit } from '@angular/core';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
  attendance: any = null;
  loading = true;
  error = '';

  constructor(private studentData: StudentDataService) {}

  ngOnInit() {
    this.studentData.getMyAttendance().subscribe({
      next: (res: any) => {
        const d = res.data || {};
        // Flatten all batch sessions into a single sorted list
        const sessions = (d.batches || []).flatMap((b: any) => b.sessions || []);
        sessions.sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
        this.attendance = {
          present:    d.totalPresent  || 0,
          absent:     d.totalAbsent   || 0,
          total:      d.totalClasses  || 0,
          percentage: d.percentage    || 0,
          records: sessions.map((s: any) => ({
            date:   s.date,
            status: s.status || 'absent',
          }))
        };
        this.loading = false;
      },
      error: (err: any) => {
        this.error = err?.error?.message || 'Could not load attendance.';
        this.loading = false;
      }
    });
  }

  getAttendEmoji(pct: number): string {
    if (pct >= 90) return '🏆';
    if (pct >= 75) return '👍';
    if (pct >= 60) return '😊';
    return '⚠️';
  }

  getBarClass(pct: number): string {
    if (pct >= 75) return 'bar--green';
    if (pct >= 50) return 'bar--amber';
    return 'bar--red';
  }

  getAttendMessage(pct: number): string {
    if (pct >= 90) return 'Outstanding! You are a star student! 🌟';
    if (pct >= 75) return 'Great job! Keep up the consistent attendance! 💪';
    if (pct >= 60) return 'Good, but try to attend more classes to learn more! 📚';
    return 'Attendance is low. Talk to your teacher for help! 🤝';
  }
}
