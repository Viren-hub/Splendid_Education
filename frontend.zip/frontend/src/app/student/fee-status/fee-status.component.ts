import { Component, OnInit } from '@angular/core';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-fee-status',
  templateUrl: './fee-status.component.html',
  styleUrls: ['./fee-status.component.css']
})
export class FeeStatusComponent implements OnInit {
  fees: any = null;
  loading = true;
  error = '';

  constructor(private studentData: StudentDataService) {}

  ngOnInit() {
    this.studentData.getMyFee().subscribe({
      next: (res: any) => {
        const fee = res.data;
        const payments = res.data?.payments || [];
        if (fee) {
          const net = fee.totalFee - (fee.discount || 0);
          const paid = fee.amountPaid || 0;
          const pending = Math.max(0, net - paid);
          this.fees = {
            currentStatus: fee.status || (pending > 0 ? 'pending' : 'paid'),
            totalFee: net,
            paid,
            pending,
            payments
          };
        }
        this.loading = false;
      },
      error: (err: any) => {
        this.error = err.userMessage || 'Could not load fee information.';
        this.loading = false;
      }
    });
  }

  printReceipt(payment: any): void {
    const win = window.open('', '_blank', 'width=600,height=500');
    if (!win) return;
    const date = new Date(payment.paymentDate || payment.createdAt)
      .toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    const noteRow = payment.note
      ? `<div class="row"><span class="label">Note</span><span class="val">${payment.note}</span></div>`
      : '';
    win.document.write(`
<!DOCTYPE html><html><head><title>Receipt #${payment.receiptNumber || 'N/A'}</title>
<style>
  body { font-family: Arial, sans-serif; padding: 40px; color: #1e293b; }
  h2 { color: #7c3aed; }
  .row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f1f5f9; }
  .label { color: #64748b; }
  .val { font-weight: 700; }
  .paid { display: inline-block; background: #dcfce7; color: #15803d; padding: 4px 14px; border-radius: 20px; font-weight: 700; }
  .footer { margin-top: 30px; text-align: center; color: #94a3b8; font-size: 12px; }
  button { background: #7c3aed; color: #fff; border: none; padding: 10px 24px; border-radius: 8px; cursor: pointer; font-size: 14px; margin-top: 20px; }
</style></head><body>
<h2>&#x1F393; Splendid Education</h2>
<p style="color:#64748b">Payment Receipt</p>
<div class="row"><span class="label">Receipt #</span><span class="val">${payment.receiptNumber || '—'}</span></div>
<div class="row"><span class="label">Amount</span><span class="val">&#x20B9;${(payment.amount || 0).toLocaleString('en-IN')}</span></div>
<div class="row"><span class="label">Date</span><span class="val">${date}</span></div>
<div class="row"><span class="label">Method</span><span class="val">${payment.method || '—'}</span></div>
<div class="row"><span class="label">Status</span><span class="paid">&#x2705; Paid</span></div>
${noteRow}
<div class="footer">Thank you for your payment! Keep learning &#x1F680;</div>
<button onclick="window.print()">&#x1F5A8; Print Receipt</button>
</body></html>`);
    win.document.close();
  }

  downloadAll(): void {
    if (!this.fees?.payments?.length) return;
    const rows = this.fees.payments.map((p: any, i: number) => {
      const d = new Date(p.paymentDate || p.createdAt)
        .toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
      return `<p>${i + 1}. &#x20B9;${(p.amount || 0).toLocaleString('en-IN')} &mdash; ${d} &mdash; ${p.method || ''} <span class="paid">Paid</span></p>`;
    }).join('');
    const win = window.open('', '_blank', 'width=700,height=600');
    if (!win) return;
    win.document.write(`
<!DOCTYPE html><html><head><title>All Receipts</title>
<style>
  body { font-family: Arial, sans-serif; padding: 40px; color: #1e293b; }
  h2 { color: #7c3aed; }
  p { border-bottom: 1px solid #f1f5f9; padding: 8px 0; font-size: 14px; }
  .paid { background: #dcfce7; color: #15803d; padding: 2px 10px; border-radius: 12px; font-weight: 700; }
  button { background: #7c3aed; color: #fff; border: none; padding: 10px 24px; border-radius: 8px; cursor: pointer; margin-top: 20px; }
</style></head><body>
<h2>&#x1F393; Splendid Education &mdash; All Payments</h2>
<p><strong>Total Paid:</strong> &#x20B9;${(this.fees.paid || 0).toLocaleString('en-IN')}</p>
${rows}
<button onclick="window.print()">&#x1F5A8; Print All</button>
</body></html>`);
    win.document.close();
  }
}
