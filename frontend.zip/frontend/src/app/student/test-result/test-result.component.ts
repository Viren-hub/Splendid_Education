import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-test-result',
  templateUrl: './test-result.component.html',
  styleUrls: ['./test-result.component.css']
})
export class TestResultComponent implements OnInit {
  attemptId = '';
  result: any = null;
  loading = true;
  error = '';
  showBreakdown = false;
  canWebShare = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private studentData: StudentDataService
  ) {}

  ngOnInit() {
    this.attemptId = this.route.snapshot.paramMap.get('attemptId') || '';
    this.canWebShare = !!(navigator as any).share;
    this.loadResult();
  }

  loadResult() {
    this.loading = true;
    this.studentData.getAttemptResult(this.attemptId).subscribe({
      next: (res: any) => {
        const raw = res?.data || res;
        // Flatten nested { attempt, quiz, breakdown } into a single result object
        const attempt  = raw.attempt  || raw;
        const quiz     = raw.quiz     || {};
        const breakdown = raw.breakdown || [];
        this.result = {
          ...attempt,
          quiz,
          questions: breakdown,
          correctAnswers: breakdown.filter((q: any) =>  q.isCorrect).length,
          wrongAnswers:   breakdown.filter((q: any) => !q.isCorrect && q.selectedOption).length,
          skipped:        breakdown.filter((q: any) => !q.selectedOption).length,
        };
        this.loading = false;
      },
      error: (err: any) => {
        this.error = err?.error?.message || 'Failed to load result';
        this.loading = false;
      }
    });
  }

  get shareText(): string {
    if (!this.result) return '';
    const title = this.result.quiz?.title || 'MCQ Test';
    const pct = Math.round(this.result.percentage);
    const badge = this.result.passed ? '🎉 Passed' : '💪 Attempted';
    return `${badge}! I scored ${pct}% in "${title}" at Splendid Education! 📚✨ #SplendidEdu #KidsCoding #LearningFun`;
  }

  shareOnWhatsApp() {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(this.shareText);
    window.open(`https://wa.me/?text=${text}%20${url}`, '_blank');
  }

  shareOnTwitter() {
    const text = encodeURIComponent(this.shareText);
    const url = encodeURIComponent(window.location.href);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
  }

  shareOnFacebook() {
    const url = encodeURIComponent(window.location.href);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
  }

  shareOnLinkedIn() {
    const url = encodeURIComponent(window.location.href);
    const summary = encodeURIComponent(this.shareText);
    window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${url}&summary=${summary}`, '_blank');
  }

  shareNative() {
    if ((navigator as any).share) {
      (navigator as any).share({
        title: `My Test Result – Splendid Education`,
        text: this.shareText,
        url: window.location.href
      }).catch(() => {});
    }
  }

  getOptionClass(q: any, opt: any): string {
    const selectedId = q.selectedOption?.id || q.selectedOption?._id || q.selectedOption;
    if (opt.isCorrect) return 'opt-correct';
    if (selectedId === String(opt.id || opt._id) && !opt.isCorrect) return 'opt-wrong';
    return '';
  }

  isSelected(q: any, opt: any): boolean {
    const selectedId = q.selectedOption?.id || q.selectedOption?._id || q.selectedOption;
    return selectedId === String(opt.id || opt._id);
  }

  goToTests() {
    this.router.navigate(['/student/tests']);
  }

  get scoreGrade(): string {
    const p = this.result?.percentage;
    if (p >= 90) return 'A+';
    if (p >= 80) return 'A';
    if (p >= 70) return 'B+';
    if (p >= 60) return 'B';
    if (p >= 50) return 'C';
    return 'F';
  }

  get gradeEmoji(): string {
    const p = this.result?.percentage;
    if (p >= 90) return '🏆';
    if (p >= 80) return '⭐';
    if (p >= 70) return '😊';
    if (p >= 60) return '👍';
    if (p >= 50) return '🙂';
    return '💪';
  }

  formatTime(seconds: number): string {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
  }
}
