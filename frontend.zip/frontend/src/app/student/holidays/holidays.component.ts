import { Component, OnInit } from '@angular/core';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-holidays',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.css']
})
export class HolidaysComponent implements OnInit {
  holidays: any[] = [];
  loading = true;

  constructor(private studentData: StudentDataService) {}

  ngOnInit() {
    this.studentData.getHolidays(new Date().getFullYear()).subscribe({
      next: (res: any) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        this.holidays = (res.data || []).filter((h: any) => new Date(h.date) >= today);
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  getHolidayEmoji(name: string): string {
    if (!name) return '🎉';
    const n = name.toLowerCase();
    if (n.includes('diwali')) return '🪔';
    if (n.includes('christmas')) return '🎄';
    if (n.includes('eid')) return '🌙';
    if (n.includes('holi')) return '🎨';
    if (n.includes('independence') || n.includes('republic')) return '🇮🇳';
    if (n.includes('new year')) return '🎆';
    if (n.includes('summer')) return '☀️';
    if (n.includes('winter')) return '❄️';
    return '🎉';
  }
}
