import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-student-tests',
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.css']
})
export class StudentTestsComponent implements OnInit {
  quizzes: any[] = [];
  loading = true;
  error = '';

  constructor(private studentData: StudentDataService, private router: Router) {}

  ngOnInit() {
    this.loadQuizzes();
  }

  loadQuizzes() {
    this.loading = true;
    this.studentData.getMyQuizzes().subscribe({
      next: (res: any) => {
        const raw = res?.data || res || [];
        this.quizzes = raw.map((q: any) => ({ ...q, attempt: q.attempt || null }));
        this.loading = false;
      },
      error: (err: any) => {
        this.error = err?.error?.message || 'Failed to load tests';
        this.loading = false;
      }
    });
  }

  startTest(quiz: any) {
    if (quiz.attempt && quiz.attempt.status === 'completed') {
      this.router.navigate(['/student/test-result', quiz.attempt.id]);
    } else {
      this.router.navigate(['/student/take-test', quiz.id]);
    }
  }

  getStatusLabel(quiz: any): string {
    if (!quiz.attempt) return 'Not Attempted';
    if (quiz.attempt.status === 'completed') return 'Completed';
    return 'In Progress';
  }

  getStatusClass(quiz: any): string {
    if (!quiz.attempt) return 'status-new';
    if (quiz.attempt.status === 'completed') return 'status-done';
    return 'status-ongoing';
  }

  getAssignmentLabel(quiz: any): string {
    if (!quiz.assignedTo) return '';
    switch (quiz.assignedTo.type) {
      case 'all': return 'All Students';
      case 'course': return `Course: ${quiz.assignedTo.course?.title || '—'}`;
      case 'batch': return `Batch: ${quiz.assignedTo.batch?.name || '—'}`;
      default: return '';
    }
  }

  // ── Summary stats ──────────────────────────────────────
  get completedQuizzes(): any[] {
    return this.quizzes.filter(q => q.attempt?.status === 'completed');
  }

  get averageScore(): number {
    const done = this.completedQuizzes;
    if (!done.length) return 0;
    const sum = done.reduce((acc, q) => acc + (parseFloat(q.attempt.percentage) || 0), 0);
    return Math.round(sum / done.length);
  }

  get passRate(): number {
    const done = this.completedQuizzes;
    if (!done.length) return 0;
    const passed = done.filter(q => q.attempt.passed).length;
    return Math.round((passed / done.length) * 100);
  }

  get bestScore(): number {
    const done = this.completedQuizzes;
    if (!done.length) return 0;
    return Math.round(Math.max(...done.map(q => parseFloat(q.attempt.percentage) || 0)));
  }

  get averageScoreClass(): string {
    if (this.averageScore >= 75) return 'stat-green';
    if (this.averageScore >= 50) return 'stat-amber';
    return 'stat-red';
  }
}
