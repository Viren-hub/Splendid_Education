import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { TokenService } from '../../core/services/token.service';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit, OnDestroy {
  user: any = null;
  profile: any = null;
  feeData: any = null;
  unreadNotifications = 0;
  loading = true;
  sidebarOpen = false;
  attendanceStats: any = null;

  // ── Quiz / test stats ────────────────────────────────────
  quizzes: any[] = [];

  // ── Session / attendance ─────────────────────────────────
  session: any = null;
  sessionLoading = false;
  sessionError = '';
  sessionTimer = '00:00:00';
  private timerInterval: any = null;

  get completedQuizzes(): any[] {
    return this.quizzes.filter(q => q.attempt?.status === 'completed');
  }

  get averageScore(): number {
    const done = this.completedQuizzes;
    if (!done.length) return 0;
    return Math.round(done.reduce((s, q) => s + (parseFloat(q.attempt.percentage) || 0), 0) / done.length);
  }

  get passRate(): number {
    const done = this.completedQuizzes;
    if (!done.length) return 0;
    return Math.round((done.filter(q => q.attempt.passed).length / done.length) * 100);
  }

  get bestScore(): number {
    const done = this.completedQuizzes;
    if (!done.length) return 0;
    return Math.round(Math.max(...done.map(q => parseFloat(q.attempt.percentage) || 0)));
  }

  get avgScoreClass(): string {
    if (this.averageScore >= 75) return 'qs-green';
    if (this.averageScore >= 50) return 'qs-amber';
    return 'qs-red';
  }

  toggleSidebar(): void { this.sidebarOpen = !this.sidebarOpen; }
  closeSidebar(): void  { this.sidebarOpen = false; }
  isExamMode(): boolean { return this.router.url.includes('/take-test/'); }

  constructor(
    private auth: AuthService,
    private tokenService: TokenService,
    private studentData: StudentDataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.user = this.tokenService.getUser();
    // Close mobile sidebar on route change
    this.router.events.subscribe(e => {
      if (e instanceof NavigationEnd) this.sidebarOpen = false;
    });
    this.studentData.getMyProfile().subscribe({
      next: (res: any) => {
        this.profile = res.data;
        // Flatten user.name onto profile so template can use profile.name directly
        if (this.profile && this.profile.user?.name) {
          this.profile.name = this.profile.user.name;
        }
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
    this.studentData.getMyFee().subscribe({
      next: (res: any) => {
        const fee = res.data;
        if (fee) {
          const net = parseFloat(fee.totalFee || 0) - parseFloat(fee.discount || 0);
          const paid = parseFloat(fee.amountPaid || 0);
          const pending = Math.max(0, net - paid);
          this.feeData = { totalFee: net, paid, pending, payments: fee.payments || [], status: fee.status };
        }
      },
      error: () => {}
    });
    this.studentData.getMyNotifications().subscribe({
      next: (res: any) => {
        this.unreadNotifications = (res.data || []).filter((n: any) => !n.isRead).length;
      },
      error: () => {}
    });
    this.studentData.getMyAttendance().subscribe({
      next: (res: any) => {
        const d = res.data || {};
        this.attendanceStats = d.totalClasses != null ? {
          percentage:   d.percentage   || 0,
          totalClasses: d.totalClasses || 0,
          totalPresent: d.totalPresent || 0,
          totalAbsent:  d.totalAbsent  || 0,
        } : null;
      },
      error: () => {}
    });
    this.studentData.getMyQuizzes().subscribe({
      next: (res: any) => {
        const raw = res?.data || res || [];
        this.quizzes = raw.map((q: any) => ({ ...q, attempt: q.attempt || null }));
      },
      error: () => {}
    });
    this.studentData.getMySession().subscribe({
      next: (res: any) => {
        this.session = res.data;
        if (this.session?.checkInAt && !this.session?.checkOutAt) {
          this.startTimer(new Date(this.session.checkInAt));
        }
      },
      error: () => {}
    });
  }

  private startTimer(checkInAt: Date) {
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - checkInAt.getTime()) / 1000);
      const h = Math.floor(elapsed / 3600);
      const m = Math.floor((elapsed % 3600) / 60);
      const s = elapsed % 60;
      this.sessionTimer = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    }, 1000);
  }

  checkIn() {
    this.sessionLoading = true;
    this.sessionError = '';
    this.studentData.checkIn().subscribe({
      next: (res: any) => {
        this.session = res.data;
        this.sessionLoading = false;
        if (this.session?.checkInAt && !this.session?.checkOutAt) {
          this.startTimer(new Date(this.session.checkInAt));
        }
      },
      error: (e: any) => {
        this.sessionError = e?.error?.message || 'Check-in failed. Try again.';
        this.sessionLoading = false;
      }
    });
  }

  checkOut() {
    this.sessionLoading = true;
    this.sessionError = '';
    this.studentData.checkOut().subscribe({
      next: (res: any) => {
        this.session = res.data;
        this.sessionLoading = false;
        if (this.timerInterval) { clearInterval(this.timerInterval); this.timerInterval = null; }
      },
      error: (e: any) => {
        this.sessionError = e?.error?.message || 'Check-out failed. Try again.';
        this.sessionLoading = false;
      }
    });
  }

  get sessionCheckedIn(): boolean {
    return !!this.session?.checkInAt && !this.session?.checkOutAt;
  }

  get sessionCheckedOut(): boolean {
    return !!this.session?.checkOutAt;
  }

  get sessionDuration(): string {
    if (!this.session?.durationMinutes) return '—';
    const h = Math.floor(this.session.durationMinutes / 60);
    const m = this.session.durationMinutes % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  }

  ngOnDestroy() {
    if (this.timerInterval) clearInterval(this.timerInterval);
  }

  showLogoutConfirm = false;

  isHome(): boolean {
    return this.router.url === '/student';
  }

  logout(): void {
    this.showLogoutConfirm = true;
  }

  confirmLogout(): void {
    this.showLogoutConfirm = false;
    // Auto check-out if still checked in
    if (this.sessionCheckedIn) {
      this.studentData.checkOut().subscribe({ error: () => {} });
    }
    this.auth.logout();
  }

  cancelLogout(): void {
    this.showLogoutConfirm = false;
  }

  printReceipt(payment: any): void {
    const win = window.open('', '_blank', 'width=600,height=500');
    if (!win) return;
    win.document.write(`
      <html><head><title>Receipt #${payment.receiptNumber || 'N/A'}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 40px; color: #1e293b; }
        h2 { color: #7c3aed; } .row { display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid #f1f5f9; }
        .label { color: #64748b; } .val { font-weight: 700; }
        .paid { display:inline-block; background:#dcfce7; color:#15803d; padding:4px 14px; border-radius:20px; font-weight:700; }
        .footer { margin-top:30px; text-align:center; color:#94a3b8; font-size:12px; }
      </style></head><body>
      <h2>🎓 Splendid Education</h2>
      <p style="color:#64748b">Payment Receipt</p>
      <div class="row"><span class="label">Receipt #</span><span class="val">${payment.receiptNumber || '—'}</span></div>
      <div class="row"><span class="label">Amount</span><span class="val">₹${(payment.amount || 0).toLocaleString('en-IN')}</span></div>
      <div class="row"><span class="label">Date</span><span class="val">${new Date(payment.paymentDate || payment.createdAt).toLocaleDateString('en-IN', {day:'2-digit',month:'short',year:'numeric'})}</span></div>
      <div class="row"><span class="label">Payment Method</span><span class="val">${payment.method || '—'}</span></div>
      <div class="row"><span class="label">Status</span><span class="paid">✅ Paid</span></div>
      ${payment.note ? `<div class="row"><span class="label">Note</span><span class="val">${payment.note}</span></div>` : ''}
      <div class="footer">Thank you for your payment! Keep learning 🚀</div>
      <br><button onclick="window.print()" style="background:#7c3aed;color:#fff;border:none;padding:10px 24px;border-radius:8px;cursor:pointer;font-size:14px;">🖨️ Print</button>
      </body></html>`);
    win.document.close();
  }

  downloadAllReceipts(): void {
    if (!this.feeData?.payments?.length) return;
    const rows = this.feeData.payments.map((p: any, i: number) =>
      `<div class="row"><b>${i+1}.</b> ₹${(p.amount||0).toLocaleString('en-IN')} &nbsp;•&nbsp; ${new Date(p.paymentDate || p.createdAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})} &nbsp;•&nbsp; ${p.method||''} &nbsp;<span class="paid">Paid</span></div>`
    ).join('');
    const win = window.open('', '_blank', 'width=700,height=600');
    if (!win) return;
    win.document.write(`
      <html><head><title>All Receipts</title>
      <style>body{font-family:Arial,sans-serif;padding:40px;color:#1e293b}h2{color:#7c3aed}.row{padding:10px 0;border-bottom:1px solid #f1f5f9;font-size:14px}.paid{background:#dcfce7;color:#15803d;padding:2px 10px;border-radius:12px;font-weight:700}</style></head><body>
      <h2>🎓 Splendid Education — All Payments</h2>
      <p style="color:#64748b">Total Paid: ₹${(this.feeData.paid||0).toLocaleString('en-IN')}</p>
      ${rows}
      <br><button onclick="window.print()" style="background:#7c3aed;color:#fff;border:none;padding:10px 24px;border-radius:8px;cursor:pointer">🖨️ Print All</button>
      </body></html>`);
    win.document.close();
  }
}
