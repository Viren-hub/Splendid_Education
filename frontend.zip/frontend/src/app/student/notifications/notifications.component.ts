import { Component, OnInit } from '@angular/core';
import { StudentDataService } from '../../core/services/student-data.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notifications: any[] = [];
  loading = true;
  justReadIds = new Set<string>();

  constructor(private studentData: StudentDataService) {}

  ngOnInit() {
    this.studentData.getMyNotifications().subscribe({
      next: (res: any) => {
        this.notifications = res.data || [];
        this.loading = false;
        // Auto mark all as read after a short delay (give user time to see "NEW")
        const unread = this.notifications.filter(n => !n.isRead);
        if (unread.length > 0) {
          setTimeout(() => this.markAllRead(), 2000);
        }
        // After a brief delay start the fade-out for all unread items
        setTimeout(() => unread.forEach(n => this.justReadIds.add(n.id)), 1800);
      },
      error: () => { this.loading = false; }
    });
  }

  get unreadCount(): number {
    return this.notifications.filter(n => !n.isRead).length;
  }

  markRead(notif: any): void {
    if (notif.isRead) return;
    this.justReadIds.add(notif.id);
    this.studentData.markNotificationRead(notif.id).subscribe({
      next: () => { notif.isRead = true; },
      error: () => {}
    });
  }

  markAllRead(): void {
    this.studentData.markAllNotificationsRead().subscribe({
      next: () => {
        this.notifications.forEach(n => n.isRead = true);
      },
      error: () => {}
    });
  }

  getNotifIcon(type: string): string {
    const icons: Record<string, string> = {
      fee: '💰', fee_reminder: '💳', schedule: '📅', holiday: '🎉',
      achievement: '🏆', general: '📢', info: 'ℹ️', warning: '⚠️',
      attendance: '📋'
    };
    return icons[type] || '📢';
  }
}
