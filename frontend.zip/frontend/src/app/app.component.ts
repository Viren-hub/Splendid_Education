import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AlertService, AlertData } from './core/services/alert.service';
import { ServerStatusService, ServerStatus } from './core/services/server-status.service';

@Component({
  selector: 'app-root',
  template: `
    <router-outlet></router-outlet>

    <!-- ── Global Toast Notification ───────────────────── -->
    <div class="g-toast g-toast--{{ alertType }}" *ngIf="alertVisible && !serverDown" role="alert" aria-live="assertive">
      <div class="g-toast-icon">
        <span *ngIf="alertType === 'error'">✕</span>
        <span *ngIf="alertType === 'success'">✓</span>
        <span *ngIf="alertType === 'info'">i</span>
      </div>
      <p class="g-toast-message">{{ alertMessage }}</p>
      <button class="g-toast-close" (click)="closeAlert()" aria-label="Close">✕</button>
      <div class="g-toast-progress"></div>
    </div>

    <!-- ── Server / DB Outage Overlay ───────────────────── -->
    <div class="outage-overlay" *ngIf="serverDown" role="alertdialog" aria-modal="true" aria-labelledby="outage-title">
      <div class="outage-card">
        <div class="outage-icon" [class.pulse]="retrying">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"
               stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path *ngIf="outageType === 'offline'"
              d="M3 3l18 18M8.56 2.9A10 10 0 0 1 22 12M1.42 9a10 10 0 0 0 1.41 6.08M10.59 10.6A5 5 0 0 1 17 17M5 5a5 5 0 0 0-.5 7.09M12 20h.01" />
            <path *ngIf="outageType !== 'offline'"
              d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
          </svg>
        </div>

        <h2 id="outage-title" class="outage-title">
          {{ outageType === 'offline' ? 'Server Unreachable' : 'Technical Issue Detected' }}
        </h2>

        <p class="outage-desc" *ngIf="outageType === 'offline'">
          We can't reach the server right now. Please check your internet connection or wait while we try to reconnect.
        </p>
        <p class="outage-desc" *ngIf="outageType !== 'offline'">
          Our backend or database is experiencing a problem. All operations are paused to prevent data loss.
          Our team has been notified.
        </p>

        <div class="outage-status-row">
          <span class="status-dot" [class.status-dot--red]="!retrying" [class.status-dot--yellow]="retrying"></span>
          <span class="outage-status-text">
            {{ retrying ? 'Attempting to reconnect…' : 'Service unavailable' }}
          </span>
        </div>

        <button class="outage-retry-btn" (click)="retryNow()" [disabled]="retrying">
          <span class="retry-spinner" *ngIf="retrying">⟳</span>
          {{ retrying ? 'Retrying…' : 'Retry Now' }}
        </button>

        <p class="outage-since" *ngIf="outageSince">
          Issue detected at {{ outageSince | date:'h:mm a' }}
        </p>
      </div>
    </div>
  `,
})
export class AppComponent implements OnInit, OnDestroy {
  alertVisible = false;
  alertMessage = '';
  alertType: 'error' | 'success' | 'info' = 'error';

  serverDown = false;
  outageType: 'offline' | 'server_error' | null = null;
  outageSince: Date | null = null;
  retrying = false;

  private _sub!: Subscription;
  private _statusSub!: Subscription;
  private _timer: any;
  private _retryTimer: any;
  private _autoRetryInterval: any;

  constructor(
    private alertService: AlertService,
    private serverStatus: ServerStatusService,
  ) {}

  ngOnInit(): void {
    this._sub = this.alertService.alert$.subscribe((data: AlertData) => {
      clearTimeout(this._timer);
      this.alertMessage = data.message;
      this.alertType = data.type;
      this.alertVisible = true;
      this._timer = setTimeout(() => this.closeAlert(), 4500);
    });

    this._statusSub = this.serverStatus.status$.subscribe((s: ServerStatus) => {
      this.serverDown = s.outage !== null;
      this.outageType = s.outage;
      this.outageSince = s.since ? new Date(s.since) : null;
      if (!this.serverDown) {
        this.retrying = false;
        clearInterval(this._autoRetryInterval);
      } else if (!this._autoRetryInterval) {
        // Auto-retry every 30s while down
        this._autoRetryInterval = setInterval(() => this.pingServer(), 30_000);
      }
    });
  }

  closeAlert(): void {
    this.alertVisible = false;
    clearTimeout(this._timer);
  }

  retryNow(): void {
    this.pingServer();
  }

  private pingServer(): void {
    if (this.retrying) return;
    this.retrying = true;
    // Fire a lightweight request; the interceptor will call recordSuccess/recordFailure
    fetch('/api/health', { method: 'HEAD' })
      .catch(() => {})
      .finally(() => {
        this._retryTimer = setTimeout(() => { this.retrying = false; }, 3000);
      });
  }

  ngOnDestroy(): void {
    this._sub?.unsubscribe();
    this._statusSub?.unsubscribe();
    clearTimeout(this._timer);
    clearTimeout(this._retryTimer);
    clearInterval(this._autoRetryInterval);
  }
}
